import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User types enum
export const UserRole = {
  ADMIN: 'admin',
  AGENT: 'agent',
  EMPLOYEE: 'employee',
} as const;

export type UserRoleType = typeof UserRole[keyof typeof UserRole];

// Break types enum
export const BreakType = {
  WASHROOM: 'WC',
  CIGARETTE: 'CY',
  MEAL: 'ML',
} as const;

export type BreakTypeType = typeof BreakType[keyof typeof BreakType];

// Break limits (in minutes)
export const BreakLimits = {
  [BreakType.WASHROOM]: 15,
  [BreakType.CIGARETTE]: 10,
  [BreakType.MEAL]: 30,
};

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  employeeId: text("employee_id").notNull().unique(), // Unique 10-digit ID
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull(),
  department: text("department"),
  position: text("position"),
  region: text("region"),
  joinDate: timestamp("join_date"),
  approvalStatus: text("approval_status").default("pending"),
  approvedBy: integer("approved_by"),
  profileImage: text("profile_image"),
  firebaseUid: text("firebase_uid"), // Store Firebase UID for users who sign in with Google
  telegramId: text("telegram_id"), // Store Telegram user ID for notifications
});

// Insert schema for users
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Break records table
export const breaks = pgTable("breaks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  breakType: text("break_type").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in seconds
  isLate: boolean("is_late").default(false),
  fineAmount: real("fine_amount").default(0),
});

// Insert schema for breaks
export const insertBreakSchema = createInsertSchema(breaks).omit({
  id: true,
  endTime: true,
  duration: true,
  isLate: true,
  fineAmount: true,
});

// Fines table
export const fines = pgTable("fines", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: real("amount").notNull(),
  reason: text("reason").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  breakId: integer("break_id"),
  reportGenerated: boolean("report_generated").default(false),
});

// Insert schema for fines
export const insertFineSchema = createInsertSchema(fines).omit({
  id: true,
  reportGenerated: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertBreak = z.infer<typeof insertBreakSchema>;
export type Break = typeof breaks.$inferSelect;

export type InsertFine = z.infer<typeof insertFineSchema>;
export type Fine = typeof fines.$inferSelect;
