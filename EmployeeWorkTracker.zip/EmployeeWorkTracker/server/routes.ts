import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertBreakSchema, 
  insertFineSchema,
  BreakLimits,
  BreakType,
  UserRole,
  type Fine
} from "@shared/schema";
import { z } from "zod";
import session from "express-session";
import MemoryStore from "memorystore";
import admin from "./firebase-admin";
import { log } from "./vite";
import { employeeBot, agentBot, adminBot } from "./telegram";
import { isFirebaseAuthenticated, registerOrLoginWithFirebase } from "./auth";

// Helper function to generate a unique 10-digit employee ID
function generateEmployeeId(): string {
  // Format: YYMM + 6 random digits
  const date = new Date();
  const year = date.getFullYear().toString().slice(2); // Last 2 digits of year
  const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Month (1-12) padded to 2 digits
  
  // Generate 6 random digits
  const randomDigits = Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
  
  return `${year}${month}${randomDigits}`;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Setup session middleware
  const MemoryStoreSession = MemoryStore(session);
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "employee-management-secret",
      resave: false,
      saveUninitialized: false,
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      cookie: {
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        secure: process.env.NODE_ENV === "production",
      },
    })
  );

  // Middleware to check if user is authenticated
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.session && req.session.userId) {
      return next();
    }
    return res.status(401).json({ message: "Unauthorized" });
  };
  
  // Firebase token verification endpoint
  app.post("/api/auth/firebase-token", async (req, res) => {
    try {
      const tokenSchema = z.object({
        idToken: z.string()
      });
      
      const { idToken } = tokenSchema.parse(req.body);
      
      try {
        // Verify the Firebase ID token
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        
        // Get user information from decoded token
        const { uid, email, name, picture } = decodedToken;
        
        // Register or login the user
        const { user, isNewUser } = await registerOrLoginWithFirebase(
          uid, 
          email || "", 
          name || email?.split("@")[0] || "User"
        );
        
        if (!user) {
          return res.status(500).json({ message: "Failed to create or update user" });
        }
        
        // Set user in session
        req.session.userId = user.id;
        req.session.userRole = user.role;
        
        // Return user without sensitive data
        const { password, ...userInfo } = user;
        
        return res.status(200).json({
          message: isNewUser ? "User registered successfully" : "User logged in successfully",
          user: userInfo,
          isNewUser
        });
      } catch (error) {
        console.error("Firebase token verification failed:", error);
        return res.status(401).json({ 
          message: "Invalid Firebase token",
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Middleware to check if user has admin role
  const isAdmin = async (req: Request, res: Response, next: Function) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden: Admin access required" });
    }
    
    return next();
  };

  // Middleware to check if user has agent role
  const isAgent = async (req: Request, res: Response, next: Function) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || (user.role !== "agent" && user.role !== "admin")) {
      return res.status(403).json({ message: "Forbidden: Agent access required" });
    }
    
    return next();
  };

  // Authentication routes
  
  // Verify Firebase ID token
  app.post("/api/auth/verify-token", async (req, res) => {
    try {
      const tokenSchema = z.object({
        idToken: z.string()
      });
      
      const { idToken } = tokenSchema.parse(req.body);
      
      try {
        // Verify the Firebase ID token using the Admin SDK
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        
        // Get user information from decoded token
        const { uid, email, name } = decodedToken;
        
        // Register or login the user with our helper function
        const { user, isNewUser } = await registerOrLoginWithFirebase(
          uid, 
          email || "", 
          name || email?.split("@")[0] || "User"
        );
        
        if (!user) {
          return res.status(500).json({ message: "Failed to create or update user" });
        }
        
        // Set user in session
        req.session.userId = user.id;
        req.session.userRole = user.role;
        
        // Return user without sensitive data
        const { password, ...userInfo } = user;
        
        return res.status(200).json({
          message: isNewUser ? "User registered successfully" : "User logged in successfully",
          user: userInfo,
          isNewUser
        });
      } catch (error) {
        console.error("Firebase token verification failed:", error);
        return res.status(401).json({ 
          message: "Invalid Firebase token",
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const loginSchema = z.object({
      username: z.string(),
      password: z.string(),
    });

    try {
      const { username, password } = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      if (user.approvalStatus !== "approved") {
        return res.status(403).json({ message: "Your account is pending approval" });
      }
      
      // Set user in session
      req.session.userId = user.id;
      req.session.userRole = user.role;
      
      // Return user info without sensitive data
      const { password: _, ...userInfo } = user;
      return res.status(200).json({ 
        message: "Login successful", 
        user: userInfo 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Firebase authentication
  app.post("/api/auth/firebase", async (req, res) => {
    try {
      const firebaseAuthSchema = z.object({
        uid: z.string(),
        email: z.string().email(),
        displayName: z.string().optional(),
        photoURL: z.string().optional()
      });
      
      const { uid, email, displayName } = firebaseAuthSchema.parse(req.body);
      
      // Use the helper function for consistent user creation/update
      const { user, isNewUser } = await registerOrLoginWithFirebase(
        uid,
        email,
        displayName || email.split('@')[0]
      );
      
      if (!user) {
        return res.status(500).json({ message: "Failed to create/update user" });
      }
      
      // Set user in session
      req.session.userId = user.id;
      req.session.userRole = user.role;
      
      // Return user info without sensitive data
      const { password, ...userInfo } = user;
      return res.status(200).json({ 
        message: isNewUser ? "User registered successfully" : "User logged in successfully",
        user: userInfo,
        isNewUser
      });
    } catch (error) {
      console.error("Firebase auth error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/auth/logout", isFirebaseAuthenticated, (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", isFirebaseAuthenticated, isAuthenticated, async (req, res) => {
    try {
      // Ensure userId exists in session
      if (!req.session.userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return user info without password
      const { password, ...userInfo } = user;
      return res.status(200).json({ user: userInfo });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // User routes
  app.post("/api/users/register", isAdmin, async (req, res) => {
    try {
      console.log("Received user registration request:", req.body);
      
      // We'll need to extend insertUserSchema to accept password
      const userDataSchema = insertUserSchema.extend({
        password: z.string().min(6)
      });
      
      try {
        // Attempt to parse the user data
        var userData = userDataSchema.parse(req.body);
        console.log("User data parsed successfully");
      } catch (parseError) {
        console.error("Failed to parse user data:", parseError);
        return res.status(400).json({ 
          message: "Invalid input data", 
          errors: parseError instanceof z.ZodError ? parseError.errors : "Validation error" 
        });
      }
      
      // Check if username or email already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        console.log("Username already exists:", userData.username);
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        console.log("Email already exists:", userData.email);
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Generate a unique employee ID if not provided
      if (!userData.employeeId) {
        userData.employeeId = generateEmployeeId();
      }
      
      // Default values for join date if not provided
      if (!userData.joinDate) {
        userData.joinDate = new Date();
      }
      
      console.log("Creating user with data:", {
        ...userData,
        password: "********" // Mask password in logs
      });
      
      try {
        var user = await storage.createUser(userData);
        console.log("User created successfully:", user.id);
      } catch (createError) {
        console.error("Database error creating user:", createError);
        return res.status(500).json({ message: "Failed to create user in database", error: createError.message });
      }
      
      // Send Telegram notification if telegramId is provided
      if (userData.telegramId) {
        try {
          const { sendTelegramNotification } = await import('./telegram');
          const welcomeMessage = `Welcome to WorkSync AI, ${userData.fullName}! 🎉\n\n`
            + `Your account has been created with the following details:\n`
            + `- Employee ID: ${userData.employeeId}\n`
            + `- Username: ${userData.username}\n`
            + `- Role: ${userData.role}\n\n`
            + `You can use this Telegram chat for various work-related tasks. Type /help to see available commands.`;
          
          sendTelegramNotification(userData.telegramId, welcomeMessage)
            .then(success => {
              if (success) {
                console.log(`Welcome notification sent to user ${userData.fullName} via Telegram`);
              } else {
                console.error(`Failed to send welcome notification to user ${userData.fullName}`);
              }
            })
            .catch(error => {
              console.error('Error sending welcome notification:', error);
            });
        } catch (error) {
          console.error('Error importing sendTelegramNotification:', error);
        }
      }
      
      // Return user without password
      const { password, ...userInfo } = user;
      return res.status(201).json({ message: "User registered successfully", user: userInfo });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      console.error("Error registering user:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getUsers();
      // Filter out passwords
      const safeUsers = users.map(({ password, ...user }) => user);
      return res.status(200).json({ users: safeUsers });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/role/:role", isAdmin, async (req, res) => {
    try {
      const { role } = req.params;
      const users = await storage.getUsersByRole(role);
      // Filter out passwords
      const safeUsers = users.map(({ password, ...user }) => user);
      return res.status(200).json({ users: safeUsers });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/approval/:status", isAdmin, async (req, res) => {
    try {
      const { status } = req.params;
      const users = await storage.getUsersByApprovalStatus(status);
      // Filter out passwords
      const safeUsers = users.map(({ password, ...user }) => user);
      return res.status(200).json({ users: safeUsers });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/:id", isFirebaseAuthenticated, isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Only admins, agents, or the user themselves can access the data
      if (
        req.session.userId !== user.id && 
        req.session.userRole !== "admin" &&
        req.session.userRole !== "agent"
      ) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Return user without password
      const { password, ...userInfo } = user;
      return res.status(200).json({ user: userInfo });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/users/:id", isFirebaseAuthenticated, isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Only admins, agents, or the user themselves can update the data
      if (
        req.session.userId !== user.id && 
        req.session.userRole !== "admin" &&
        req.session.userRole !== "agent"
      ) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // If not admin, restrict which fields can be updated
      const updateData = req.body;
      if (req.session.userRole !== "admin") {
        // Non-admins can only update certain fields
        const allowedFields = ["fullName", "email", "password", "profileImage"];
        Object.keys(updateData).forEach(key => {
          if (!allowedFields.includes(key)) {
            delete updateData[key];
          }
        });
      }
      
      const updatedUser = await storage.updateUser(userId, updateData);
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update user" });
      }
      
      // Return user without password
      const { password, ...userInfo } = updatedUser;
      return res.status(200).json({ message: "User updated successfully", user: userInfo });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/users/:id", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const deleted = await storage.deleteUser(userId);
      
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.status(200).json({ message: "User deleted successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/users/:id/approve", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, {
        approvalStatus: "approved",
        approvedBy: req.session.userId
      });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to approve user" });
      }
      
      // Return user without password
      const { password, ...userInfo } = updatedUser;
      return res.status(200).json({ 
        message: "User approved successfully", 
        user: userInfo 
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/users/:id/reject", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, {
        approvalStatus: "rejected",
        approvedBy: req.session.userId
      });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to reject user" });
      }
      
      // Return user without password
      const { password, ...userInfo } = updatedUser;
      return res.status(200).json({ 
        message: "User rejected successfully", 
        user: userInfo 
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Break routes
  app.post("/api/breaks", isFirebaseAuthenticated, isAuthenticated, async (req, res) => {
    try {
      // Ensure userId exists in session
      if (!req.session.userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const breakData = insertBreakSchema.parse({
        ...req.body,
        userId: req.session.userId,
        startTime: new Date()
      });
      
      // Check if user already has an active break
      const activeBreak = await storage.getUserActiveBreak(req.session.userId);
      if (activeBreak) {
        return res.status(400).json({ 
          message: "You already have an active break", 
          break: activeBreak 
        });
      }
      
      const newBreak = await storage.createBreak(breakData);
      return res.status(201).json({ 
        message: "Break started successfully", 
        break: newBreak 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/breaks/:id/end", isFirebaseAuthenticated, isAuthenticated, async (req, res) => {
    try {
      const breakId = parseInt(req.params.id);
      const breakRecord = await storage.getBreak(breakId);
      
      if (!breakRecord) {
        return res.status(404).json({ message: "Break not found" });
      }
      
      // Only the user who started the break or an admin can end it
      if (
        breakRecord.userId !== req.session.userId && 
        req.session.userRole !== "admin"
      ) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Calculate break duration and check if late
      const endTime = new Date();
      const startTime = new Date(breakRecord.startTime);
      const durationSeconds = Math.floor((endTime.getTime() - startTime.getTime()) / 1000);
      
      // Get break limit in seconds
      const breakLimitSeconds = BreakLimits[breakRecord.breakType as keyof typeof BreakLimits] * 60;
      
      // Check if break is late
      const isLate = durationSeconds > breakLimitSeconds;
      
      // Calculate fine amount if late
      let fineAmount = 0;
      if (isLate) {
        const extraMinutes = Math.ceil((durationSeconds - breakLimitSeconds) / 60);
        
        // WC and CY breaks have a flat $10 fine, plus $1 per extra minute
        if (breakRecord.breakType === BreakType.WASHROOM || 
            breakRecord.breakType === BreakType.CIGARETTE) {
          fineAmount = 10 + extraMinutes;
        } 
        // ML breaks have $1 per extra minute
        else if (breakRecord.breakType === BreakType.MEAL) {
          fineAmount = extraMinutes;
        }
      }
      
      // Update break record
      const updatedBreak = await storage.updateBreak(breakId, {
        endTime,
        duration: durationSeconds,
        isLate,
        fineAmount
      });
      
      // Create fine record if there's a fine
      if (fineAmount > 0) {
        const breakTypeNames = {
          [BreakType.WASHROOM]: "Washroom Break",
          [BreakType.CIGARETTE]: "Cigarette Break",
          [BreakType.MEAL]: "Meal Break"
        };
        
        const fineData = {
          userId: breakRecord.userId,
          amount: fineAmount,
          reason: `Late return from ${breakTypeNames[breakRecord.breakType as keyof typeof breakTypeNames]}`,
          timestamp: endTime,
          breakId: breakId
        };
        
        await storage.createFine(fineData);
      }
      
      return res.status(200).json({
        message: isLate ? "Break ended - you were late and received a fine" : "Break ended successfully",
        break: updatedBreak,
        fine: isLate ? { amount: fineAmount } : null
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/breaks/user/:userId", isFirebaseAuthenticated, isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Only the user themselves or an admin can view the breaks
      if (
        userId !== req.session.userId && 
        req.session.userRole !== "admin" &&
        req.session.userRole !== "agent"
      ) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const breaks = await storage.getBreaksByUser(userId);
      return res.status(200).json({ breaks });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/breaks/active", isAuthenticated, async (req, res) => {
    try {
      // Ensure userId exists in session
      if (!req.session.userId || !req.session.userRole) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // For employees, only return their own active break
      if (req.session.userRole === "employee") {
        const activeBreak = await storage.getUserActiveBreak(req.session.userId);
        return res.status(200).json({ 
          breaks: activeBreak ? [activeBreak] : [] 
        });
      }
      
      // For admins and agents, return all active breaks
      const activeBreaks = await storage.getActiveBreaks();
      return res.status(200).json({ breaks: activeBreaks });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Fine routes
  app.get("/api/fines/user/:userId", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Only the user themselves or an admin can view the fines
      if (
        userId !== req.session.userId && 
        req.session.userRole !== "admin" &&
        req.session.userRole !== "agent"
      ) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const fines = await storage.getFinesByUser(userId);
      const totalFines = await storage.getTotalFinesByUser(userId);
      const monthlyFines = await storage.getMonthlyFinesByUser(userId);
      
      return res.status(200).json({ 
        fines,
        total: totalFines,
        monthly: monthlyFines
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Stats routes for admin dashboard
  app.get("/api/stats", isAdmin, async (req, res) => {
    try {
      const allUsers = await storage.getUsers();
      const employees = allUsers.filter(user => user.role === "employee");
      const agents = allUsers.filter(user => user.role === "agent");
      const pendingApprovals = allUsers.filter(user => user.approvalStatus === "pending");
      const activeBreaks = await storage.getActiveBreaks();
      
      // Calculate total fines for the current month
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      
      // Get all fines
      interface UserFine {
        id: number;
        userId: number;
        amount: number;
        reason: string;
        timestamp: Date;
        breakId: number | null;
      }
      
      let allFines: UserFine[] = [];
      for (const user of allUsers) {
        const userFines = await storage.getFinesByUser(user.id);
        allFines = [...allFines, ...userFines];
      }
      
      // Filter for current month fines
      const monthlyFines = allFines.filter(fine => {
        const fineDate = new Date(fine.timestamp);
        return fineDate >= startOfMonth && fineDate <= now;
      });
      
      const totalMonthlyFines = monthlyFines.reduce(
        (total, fine) => total + fine.amount, 
        0
      );
      
      return res.status(200).json({
        employeeCount: employees.length,
        agentCount: agents.length,
        pendingApprovalsCount: pendingApprovals.length,
        activeBreaksCount: activeBreaks.length,
        monthlyFinesTotal: totalMonthlyFines
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Telegram bot status endpoint
  app.get("/api/telegram/status", (req, res) => {
    try {
      const status = {
        employee_bot: {
          is_running: !!employeeBot,
          name: "Employee Bot",
          token_valid: true
        },
        agent_bot: {
          is_running: !!agentBot,
          name: "Agent Bot",
          token_valid: true
        },
        admin_bot: {
          is_running: !!adminBot,
          name: "Admin Bot",
          token_valid: true
        },
        timestamp: new Date().toISOString()
      };
      
      return res.status(200).json(status);
    } catch (error) {
      console.error("Error getting Telegram bot status:", error);
      return res.status(500).json({ 
        message: "Failed to get Telegram bot status",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    return res.status(200).json({ 
      status: "ok",
      message: "Server is running",
      timestamp: new Date().toISOString()
    });
  });

  return httpServer;
}
