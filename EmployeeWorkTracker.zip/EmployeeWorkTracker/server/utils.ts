/**
 * Format a duration in milliseconds to a human-readable format
 */
export function formatDuration(durationMs: number): string {
  const seconds = Math.floor((durationMs / 1000) % 60);
  const minutes = Math.floor((durationMs / (1000 * 60)) % 60);
  const hours = Math.floor((durationMs / (1000 * 60 * 60)) % 24);
  
  const parts = [];
  if (hours > 0) {
    parts.push(`${hours}h`);
  }
  if (minutes > 0 || hours > 0) {
    parts.push(`${minutes}m`);
  }
  parts.push(`${seconds}s`);
  
  return parts.join(' ');
}

/**
 * Format a date to a readable string
 */
export function formatDate(date: Date): string {
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

/**
 * Generate a random password
 */
export function generateRandomPassword(length: number = 8): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let password = '';
  
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * chars.length);
    password += chars.charAt(randomIndex);
  }
  
  return password;
}

/**
 * Format currency as USD
 */
export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Generate a unique employee ID
 * Format: YYMM + 6 random digits
 */
export function generateEmployeeId(): string {
  const date = new Date();
  const year = date.getFullYear().toString().slice(2); // Last 2 digits of year
  const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Month with leading zero
  
  // Generate 6 random digits
  const randomPart = Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
  
  return `${year}${month}${randomPart}`;
}