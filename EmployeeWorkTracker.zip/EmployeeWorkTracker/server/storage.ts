import { 
  users, 
  breaks, 
  fines, 
  type User, 
  type InsertUser, 
  type Break, 
  type InsertBreak,
  type Fine,
  type InsertFine,
  UserRole
} from "@shared/schema";
import { db } from "./db";
import { eq, and, isNull, gte, lte, desc } from "drizzle-orm";
import * as crypto from "crypto";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByEmployeeId(employeeId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  getUsersByApprovalStatus(status: string): Promise<User[]>;
  
  // Break operations
  createBreak(breakData: InsertBreak): Promise<Break>;
  getBreak(id: number): Promise<Break | undefined>;
  updateBreak(id: number, breakData: Partial<Break>): Promise<Break | undefined>;
  getBreaksByUser(userId: number): Promise<Break[]>;
  getActiveBreaks(): Promise<Break[]>;
  getUserActiveBreak(userId: number): Promise<Break | undefined>;
  
  // Fine operations
  createFine(fine: InsertFine): Promise<Fine>;
  getFine(id: number): Promise<Fine | undefined>;
  getFinesByUser(userId: number): Promise<Fine[]>;
  updateFine(id: number, fine: Partial<Fine>): Promise<Fine | undefined>;
  getTotalFinesByUser(userId: number): Promise<number>;
  getMonthlyFinesByUser(userId: number): Promise<number>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // Generate a unique 10-digit employee ID
  private generateEmployeeId(): string {
    // Create a random ID with a specific format
    const randomPart = crypto.randomInt(100000000, 999999999);
    return `1${randomPart}`;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email));
    return user;
  }

  async getUserByEmployeeId(employeeId: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.employeeId, employeeId));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    // If employeeId is not provided, generate one
    if (!userData.employeeId) {
      userData.employeeId = this.generateEmployeeId();
    }
    // Set join date if not provided
    if (!userData.joinDate) {
      userData.joinDate = new Date();
    }
    
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db
      .delete(users)
      .where(eq(users.id, id))
      .returning({ id: users.id });
    
    return result.length > 0;
  }

  async getUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return db
      .select()
      .from(users)
      .where(eq(users.role, role));
  }

  async getUsersByApprovalStatus(status: string): Promise<User[]> {
    return db
      .select()
      .from(users)
      .where(eq(users.approvalStatus, status));
  }

  // Break operations
  async createBreak(breakData: InsertBreak): Promise<Break> {
    const [newBreak] = await db
      .insert(breaks)
      .values(breakData)
      .returning();
    
    return newBreak;
  }

  async getBreak(id: number): Promise<Break | undefined> {
    const [breakRecord] = await db
      .select()
      .from(breaks)
      .where(eq(breaks.id, id));
    
    return breakRecord;
  }

  async updateBreak(id: number, breakData: Partial<Break>): Promise<Break | undefined> {
    const [updatedBreak] = await db
      .update(breaks)
      .set(breakData)
      .where(eq(breaks.id, id))
      .returning();
    
    return updatedBreak;
  }

  async getBreaksByUser(userId: number): Promise<Break[]> {
    return db
      .select()
      .from(breaks)
      .where(eq(breaks.userId, userId))
      .orderBy(desc(breaks.startTime));
  }

  async getActiveBreaks(): Promise<Break[]> {
    return db
      .select()
      .from(breaks)
      .where(isNull(breaks.endTime));
  }

  async getUserActiveBreak(userId: number): Promise<Break | undefined> {
    const [activeBreak] = await db
      .select()
      .from(breaks)
      .where(and(
        eq(breaks.userId, userId),
        isNull(breaks.endTime)
      ));
    
    return activeBreak;
  }

  // Fine operations
  async createFine(fineData: InsertFine): Promise<Fine> {
    const [fine] = await db
      .insert(fines)
      .values(fineData)
      .returning();
    
    return fine;
  }

  async getFine(id: number): Promise<Fine | undefined> {
    const [fine] = await db
      .select()
      .from(fines)
      .where(eq(fines.id, id));
    
    return fine;
  }

  async getFinesByUser(userId: number): Promise<Fine[]> {
    return db
      .select()
      .from(fines)
      .where(eq(fines.userId, userId))
      .orderBy(desc(fines.timestamp));
  }

  async updateFine(id: number, fineData: Partial<Fine>): Promise<Fine | undefined> {
    const [updatedFine] = await db
      .update(fines)
      .set(fineData)
      .where(eq(fines.id, id))
      .returning();
    
    return updatedFine;
  }

  async getTotalFinesByUser(userId: number): Promise<number> {
    // Get all fines for the user and calculate total manually
    const userFines = await this.getFinesByUser(userId);
    return userFines.reduce((total, fine) => total + fine.amount, 0);
  }

  async getMonthlyFinesByUser(userId: number): Promise<number> {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    // Get all fines for the user and filter by date
    const userFines = await this.getFinesByUser(userId);
    return userFines
      .filter(fine => {
        const fineDate = new Date(fine.timestamp);
        return fineDate >= startOfMonth && fineDate <= now;
      })
      .reduce((total, fine) => total + fine.amount, 0);
  }
}

// Create an instance of the database storage
export const storage = new DatabaseStorage();
