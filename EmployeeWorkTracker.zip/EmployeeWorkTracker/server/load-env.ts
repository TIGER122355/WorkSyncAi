/**
 * Load environment variables from .env file
 * This is necessary because sometimes the environment variables in Replit
 * are not updated when the .env file is changed.
 */
import fs from 'fs';
import { config } from 'dotenv';
import path from 'path';

// Force reload environment variables from .env file
export function forceLoadEnvVars() {
  try {
    // First try standard dotenv loading
    const result = config();
    
    if (!result.parsed) {
      console.warn('No environment variables loaded from .env file using dotenv.');
      
      // If that fails, try to manually load the .env file
      const envPath = path.resolve(process.cwd(), '.env');
      console.log('Trying to load .env file from:', envPath);
      
      if (fs.existsSync(envPath)) {
        const envContent = fs.readFileSync(envPath, 'utf8');
        const envVars = parseEnvFile(envContent);
        
        // Set environment variables
        for (const [key, value] of Object.entries(envVars)) {
          if (!process.env[key]) {
            process.env[key] = value;
          }
        }
        
        console.log('Environment variables manually loaded from .env file.');
      } else {
        console.warn('.env file not found at path:', envPath);
      }
    } else {
      console.log('Environment variables loaded from .env file using dotenv.');
    }
  } catch (error) {
    console.error('Error loading environment variables:', error);
  }
}

// Helper function to parse .env file content
function parseEnvFile(content: string): Record<string, string> {
  const result: Record<string, string> = {};
  
  const lines = content.split('\n');
  for (const line of lines) {
    // Skip comments and empty lines
    if (!line || line.startsWith('#')) {
      continue;
    }
    
    // Split by first equals sign
    const equalSignPos = line.indexOf('=');
    if (equalSignPos > 0) {
      const key = line.slice(0, equalSignPos).trim();
      const value = line.slice(equalSignPos + 1).trim();
      
      // Remove quotes if present
      const cleanValue = value.replace(/^['"]|['"]$/g, '');
      
      result[key] = cleanValue;
    }
  }
  
  return result;
}

// Display all Telegram bot tokens for debugging
export function logTelegramBotTokens() {
  console.log('Current Telegram bot tokens:');
  console.log('- TELEGRAM_EMPLOYEE_BOT_TOKEN:', process.env.TELEGRAM_EMPLOYEE_BOT_TOKEN ? 
    `${process.env.TELEGRAM_EMPLOYEE_BOT_TOKEN.substring(0, 10)}...` : 'undefined');
  console.log('- TELEGRAM_AGENT_BOT_TOKEN:', process.env.TELEGRAM_AGENT_BOT_TOKEN ? 
    `${process.env.TELEGRAM_AGENT_BOT_TOKEN.substring(0, 10)}...` : 'undefined');
  console.log('- TELEGRAM_ADMIN_BOT_TOKEN:', process.env.TELEGRAM_ADMIN_BOT_TOKEN ? 
    `${process.env.TELEGRAM_ADMIN_BOT_TOKEN.substring(0, 10)}...` : 'undefined');
  console.log('- TELEGRAM_ADMIN_PASSWORD:', process.env.TELEGRAM_ADMIN_PASSWORD ? 
    'Configured (custom)' : 'Using default password');
}