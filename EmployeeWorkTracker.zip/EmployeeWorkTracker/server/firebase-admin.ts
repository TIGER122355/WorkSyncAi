import admin from 'firebase-admin';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { log } from './vite';

// Initialize Firebase Admin with service account credentials
try {
  // Get current file path (ESM equivalent of __dirname)
  const currentFilePath = fileURLToPath(import.meta.url);
  const currentDirPath = dirname(currentFilePath);
  
  // Read the service account file
  const serviceAccountPath = join(currentDirPath, 'firebase-service-account.json');
  const serviceAccountContent = readFileSync(serviceAccountPath, 'utf8');
  const serviceAccount = JSON.parse(serviceAccountContent);
  
  // Initialize the app if not already initialized
  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      databaseURL: `https://${serviceAccount.project_id}.firebaseio.com`
    });
    log('Firebase Admin SDK initialized successfully', 'firebase');
  }
} catch (error) {
  console.error('Error initializing Firebase Admin SDK:', error);
  
  // Fallback to default credentials if service account fails
  if (!admin.apps.length) {
    try {
      admin.initializeApp({
        projectId: process.env.VITE_FIREBASE_PROJECT_ID || 'worksync-ai-715b3'
      });
      log('Firebase Admin SDK initialized with app default credentials (fallback)', 'firebase');
    } catch (fallbackError) {
      console.error('Failed to initialize Firebase Admin with fallback:', fallbackError);
    }
  }
}

export default admin;