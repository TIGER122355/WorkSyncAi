import TelegramBot from 'node-telegram-bot-api';
import { BaseTelegramBot } from './base-bot';
import { storage } from '../storage';
import { User, Break, BreakType, BreakLimits, UserRole } from '@shared/schema';
import { formatDuration, formatCurrency } from '../utils';

export class EmployeeTelegramBot extends BaseTelegramBot {
  constructor(token: string) {
    super(token, 'Employee');
    this.startSessionCleanup();
  }
  
  protected registerHandlers() {
    // Register specific handlers for employee bot
    this.bot.onText(/\/status/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.sendStatusUpdate(chatId);
    });
    
    this.bot.onText(/\/break (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      const breakType = match?.[1]?.toUpperCase();
      if (!breakType || !Object.values(BreakType).includes(breakType as any)) {
        this.bot.sendMessage(
          chatId, 
          `Invalid break type. Available options: ${Object.values(BreakType).join(', ')}`
        );
        return;
      }
      
      await this.startBreak(chatId, breakType as BreakTypeType);
    });
    
    this.bot.onText(/\/end/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.endBreak(chatId);
    });
    
    this.bot.onText(/\/fines/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.showFines(chatId);
    });
  }
  
  protected sendHelpMessage(chatId: number) {
    const helpMessage = `
*Employee Bot Commands*:

/start - Start the bot and authenticate
/status - Check your current break status
/break TYPE - Start a break (Types: ${Object.values(BreakType).join(', ')})
/end - End your current break
/fines - View your fine history
/help - Show this help message
/logout - Log out from the bot

*Break Limits*:
- ${BreakType.WASHROOM}: ${BreakLimits[BreakType.WASHROOM]} minutes
- ${BreakType.CIGARETTE}: ${BreakLimits[BreakType.CIGARETTE]} minutes
- ${BreakType.MEAL}: ${BreakLimits[BreakType.MEAL]} minutes

*Fine Rules*:
- Late return: $10
- Additional time: $1 per minute
`;
    
    this.bot.sendMessage(chatId, helpMessage, { parse_mode: 'Markdown' });
  }
  
  protected async handleMessage(chatId: number, msg: any) {
    // Handle messages based on the current state
    const state = this.getUserState(chatId);
    
    if (!state) {
      this.bot.sendMessage(chatId, 'Please use one of the available commands. Type /help to see options.');
      return;
    }
    
    // For now, employee bot doesn't need additional message handling beyond commands
    this.bot.sendMessage(chatId, 'Please use one of the available commands. Type /help to see options.');
  }
  
  protected async authenticateUser(chatId: number, employeeId: string): Promise<User | null> {
    // For employee bot, we authenticate by employee ID only - no password required
    try {
      // Check if the input is a valid employee ID
      const user = await storage.getUserByEmployeeId(employeeId);
      
      // Only authenticate if the user is an employee
      if (user && user.role === UserRole.EMPLOYEE) {
        return user;
      }
      
      return null;
    } catch (error) {
      console.error('Error authenticating employee:', error);
      return null;
    }
  }
  
  // Helper methods
  
  private async sendStatusUpdate(chatId: number) {
    const userId = this.getUserId(chatId);
    if (!userId) return;
    
    try {
      // Get user
      const user = await storage.getUser(userId);
      if (!user) {
        this.bot.sendMessage(chatId, 'Error: User not found');
        return;
      }
      
      // Check if user has an active break
      const activeBreak = await storage.getUserActiveBreak(userId);
      
      if (activeBreak) {
        const startTime = new Date(activeBreak.startTime);
        const now = new Date();
        const duration = Math.floor((now.getTime() - startTime.getTime()) / 60000); // in minutes
        const limit = BreakLimits[activeBreak.breakType as keyof typeof BreakLimits];
        const remaining = Math.max(0, limit - duration);
        
        let statusMessage = `
*Current Break Status*:
Type: ${activeBreak.breakType}
Started: ${startTime.toLocaleTimeString()}
Duration: ${duration} minutes
Time limit: ${limit} minutes
Remaining: ${remaining} minutes
`;

        if (duration > limit) {
          const overtime = duration - limit;
          const fine = 10 + overtime;
          statusMessage += `\n⚠️ *Warning*: You are ${overtime} minutes over your break limit.\nEstimated fine: $${fine}`;
        }
        
        this.bot.sendMessage(chatId, statusMessage, { parse_mode: 'Markdown' });
      } else {
        this.bot.sendMessage(chatId, 'You have no active breaks.');
      }
    } catch (error) {
      console.error('Error getting status:', error);
      this.bot.sendMessage(chatId, 'An error occurred while getting your status.');
    }
  }
  
  private async startBreak(chatId: number, breakType: BreakTypeType) {
    const userId = this.getUserId(chatId);
    if (!userId) return;
    
    try {
      // Check if the user already has an active break
      const activeBreak = await storage.getUserActiveBreak(userId);
      
      if (activeBreak) {
        this.bot.sendMessage(
          chatId, 
          `You already have an active ${activeBreak.breakType} break. Please end it before starting a new one.`
        );
        return;
      }
      
      // Create a new break
      const newBreak = await storage.createBreak({
        userId,
        breakType: breakType,
        startTime: new Date()
      });
      
      // Send confirmation message
      this.bot.sendMessage(
        chatId,
        `Started ${breakType} break. You have ${BreakLimits[breakType as keyof typeof BreakLimits]} minutes.\nUse /end to end your break.`,
        { parse_mode: 'Markdown' }
      );
    } catch (error) {
      console.error('Error starting break:', error);
      this.bot.sendMessage(chatId, 'An error occurred while starting your break.');
    }
  }
  
  private async endBreak(chatId: number) {
    const userId = this.getUserId(chatId);
    if (!userId) return;
    
    try {
      // Check if the user has an active break
      const activeBreak = await storage.getUserActiveBreak(userId);
      
      if (!activeBreak) {
        this.bot.sendMessage(chatId, 'You do not have an active break to end.');
        return;
      }
      
      // Calculate break duration
      const startTime = new Date(activeBreak.startTime);
      const endTime = new Date();
      const duration = Math.floor((endTime.getTime() - startTime.getTime()) / 60000); // in minutes
      
      // Update the break record
      const updatedBreak = await storage.updateBreak(activeBreak.id, {
        endTime,
        duration,
        isLate: duration > BreakLimits[activeBreak.breakType as keyof typeof BreakLimits]
      });
      
      // Check if the break exceeded its limit and create a fine if needed
      const limit = BreakLimits[activeBreak.breakType as keyof typeof BreakLimits];
      let fineMessage = '';
      
      if (duration > limit) {
        const overtime = duration - limit;
        const fineAmount = 10 + overtime; // $10 base fine + $1 per minute overtime
        
        // Create a fine record
        const fine = await storage.createFine({
          userId,
          amount: fineAmount,
          reason: `Exceeded ${activeBreak.breakType} break limit by ${overtime} minutes`,
          timestamp: new Date(),
          breakId: activeBreak.id
        });
        
        fineMessage = `\n⚠️ *Fine*: $${fineAmount} for exceeding the break limit by ${overtime} minutes.`;
      }
      
      // Send confirmation message
      this.bot.sendMessage(
        chatId,
        `Break ended. Duration: ${duration} minutes.${fineMessage}`,
        { parse_mode: 'Markdown' }
      );
    } catch (error) {
      console.error('Error ending break:', error);
      this.bot.sendMessage(chatId, 'An error occurred while ending your break.');
    }
  }
  
  private async showFines(chatId: number) {
    const userId = this.getUserId(chatId);
    if (!userId) return;
    
    try {
      // Get user's fines
      const fines = await storage.getFinesByUser(userId);
      
      if (fines.length === 0) {
        this.bot.sendMessage(chatId, 'You have no fines. Keep up the good work!');
        return;
      }
      
      // Calculate total fine amount
      const totalAmount = fines.reduce((sum, fine) => sum + fine.amount, 0);
      
      // Format fines as a message
      let finesMessage = `*Your Fine History* (Total: $${totalAmount})\n\n`;
      
      fines.forEach((fine, index) => {
        finesMessage += `${index + 1}. *$${fine.amount}* - ${fine.reason}\n   ${new Date(fine.timestamp).toLocaleString()}\n\n`;
      });
      
      this.bot.sendMessage(chatId, finesMessage, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error getting fines:', error);
      this.bot.sendMessage(chatId, 'An error occurred while retrieving your fines.');
    }
  }
}

// For TypeScript
type BreakTypeType = typeof BreakType[keyof typeof BreakType];