import TelegramBot from 'node-telegram-bot-api';
import { BaseTelegramBot } from './base-bot';
import { storage } from '../storage';
import { User, Break, BreakType, BreakLimits, UserRole } from '@shared/schema';
import { formatDate, formatCurrency, generateRandomPassword, generateEmployeeId } from '../utils';

export class AdminTelegramBot extends BaseTelegramBot {
  constructor(token: string) {
    super(token, 'Admin');
    this.startSessionCleanup();
  }
  
  protected registerHandlers() {
    // Register specific handlers for admin bot
    this.bot.onText(/\/stats/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.showSystemStats(chatId);
    });
    
    this.bot.onText(/\/users/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.listAllUsers(chatId);
    });
    
    this.bot.onText(/\/fines/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.showFinesSummary(chatId);
    });
    
    this.bot.onText(/\/create/, (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      this.setUserState(chatId, 'CREATE_USER_NAME');
      this.bot.sendMessage(chatId, 'Let\'s create a new user. Please enter the user\'s full name:');
    });
    
    this.bot.onText(/\/reset (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      const employeeId = match?.[1];
      if (!employeeId) {
        this.bot.sendMessage(chatId, 'Please provide an employee ID to reset password.');
        return;
      }
      
      await this.resetUserPassword(chatId, employeeId);
    });
    
    this.bot.onText(/\/delete (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      const employeeId = match?.[1];
      if (!employeeId) {
        this.bot.sendMessage(chatId, 'Please provide an employee ID to delete.');
        return;
      }
      
      // Set state to confirm deletion
      this.setUserState(chatId, 'CONFIRM_DELETE', { employeeId });
      this.bot.sendMessage(
        chatId, 
        `Are you sure you want to delete user with employee ID ${employeeId}? Reply 'YES' to confirm or 'NO' to cancel.`
      );
    });
    
    this.bot.onText(/\/search (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      const query = match?.[1];
      if (!query) {
        this.bot.sendMessage(chatId, 'Please provide a search query.');
        return;
      }
      
      await this.searchUsers(chatId, query);
    });
    
    this.bot.onText(/\/active/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.listActiveBreaks(chatId);
    });
  }
  
  protected sendHelpMessage(chatId: number) {
    const helpMessage = `
*Admin Bot Commands*:

/start - Start the bot and authenticate
/stats - Show system statistics
/users - List all users
/fines - Show fines summary
/create - Create a new user
/reset EMPLOYEE_ID - Reset a user's password
/delete EMPLOYEE_ID - Delete a user
/search QUERY - Search for users
/active - List all active breaks
/help - Show this help message
/logout - Log out from the bot
`;
    
    this.bot.sendMessage(chatId, helpMessage, { parse_mode: 'Markdown' });
  }
  
  protected async handleMessage(chatId: number, msg: any) {
    // Handle messages based on the current state
    const stateInfo = this.getUserState(chatId);
    
    if (!stateInfo) {
      this.bot.sendMessage(chatId, 'Please use one of the available commands. Type /help to see options.');
      return;
    }
    
    const { state, data } = stateInfo;
    const text = msg.text || '';
    
    switch (state) {
      case 'CREATE_USER_NAME':
        // Store the name and ask for email
        this.setUserState(chatId, 'CREATE_USER_EMAIL', { name: text });
        this.bot.sendMessage(chatId, 'Please enter the user\'s email address:');
        break;
        
      case 'CREATE_USER_EMAIL':
        // Validate email format
        if (!text.includes('@') || !text.includes('.')) {
          this.bot.sendMessage(chatId, 'Invalid email format. Please enter a valid email address:');
          return;
        }
        
        // Store email and ask for role
        this.setUserState(chatId, 'CREATE_USER_ROLE', { ...data, email: text });
        this.bot.sendMessage(
          chatId, 
          `Please select the user's role: ${Object.values(UserRole).join(', ')}`
        );
        break;
        
      case 'CREATE_USER_ROLE':
        // Validate role
        const role = text.toUpperCase();
        if (!Object.values(UserRole).includes(role as any)) {
          this.bot.sendMessage(
            chatId, 
            `Invalid role. Please select one of: ${Object.values(UserRole).join(', ')}`
          );
          return;
        }
        
        // Store role and ask for username
        this.setUserState(chatId, 'CREATE_USER_USERNAME', { ...data, role });
        this.bot.sendMessage(chatId, 'Please enter a username for the user:');
        break;
        
      case 'CREATE_USER_USERNAME':
        // Store username and create the user
        await this.createNewUser(chatId, { ...data, username: text });
        break;
        
      case 'CONFIRM_DELETE':
        if (text.toUpperCase() === 'YES') {
          await this.deleteUser(chatId, data.employeeId);
        } else {
          this.bot.sendMessage(chatId, 'User deletion cancelled.');
          this.setUserState(chatId, 'INITIAL');
        }
        break;
        
      default:
        this.bot.sendMessage(chatId, 'Please use one of the available commands. Type /help to see options.');
    }
  }
  
  protected async authenticateUser(chatId: number, password: string): Promise<User | null> {
    try {
      // Get admin password from environment variable with fallback to default
      const adminPassword = process.env.TELEGRAM_ADMIN_PASSWORD || 'admin123';
      
      // Compare provided password with the configured one
      if (password === adminPassword) {
        // If password matches, return the first admin user
        const admins = await storage.getUsersByRole(UserRole.ADMIN);
        
        if (admins.length > 0) {
          return admins[0];
        }
        
        // If no admins exist, create a default one
        const newAdmin = await storage.createUser({
          fullName: 'Default Admin',
          email: 'admin@example.com',
          role: UserRole.ADMIN,
          username: 'admin',
          employeeId: 'ADMIN001',
          approvalStatus: 'APPROVED',
          password: adminPassword
        });
        
        return newAdmin;
      }
      
      return null;
    } catch (error) {
      console.error('Error authenticating admin:', error);
      return null;
    }
  }
  
  // Helper methods
  
  private async showSystemStats(chatId: number) {
    try {
      // Get counts of different types of users
      const allUsers = await storage.getUsers();
      const employees = allUsers.filter(user => user.role === 'EMPLOYEE');
      const agents = allUsers.filter(user => user.role === 'AGENT');
      const admins = allUsers.filter(user => user.role === 'ADMIN');
      
      // Get counts of pending and approved users
      const pendingUsers = allUsers.filter(user => user.approvalStatus === 'PENDING');
      const approvedUsers = allUsers.filter(user => user.approvalStatus === 'APPROVED');
      const rejectedUsers = allUsers.filter(user => user.approvalStatus === 'REJECTED');
      
      // Get active breaks
      const activeBreaks = await storage.getActiveBreaks();
      
      // Aggregate break types
      const breakTypeCounts = activeBreaks.reduce((counts, breakItem) => {
        counts[breakItem.breakType] = (counts[breakItem.breakType] || 0) + 1;
        return counts;
      }, {} as Record<string, number>);
      
      // Format the message
      let message = '*System Statistics*\n\n';
      
      message += '*Users*:\n';
      message += `Total: ${allUsers.length}\n`;
      message += `Employees: ${employees.length}\n`;
      message += `Agents: ${agents.length}\n`;
      message += `Admins: ${admins.length}\n\n`;
      
      message += '*User Status*:\n';
      message += `Pending: ${pendingUsers.length}\n`;
      message += `Approved: ${approvedUsers.length}\n`;
      message += `Rejected: ${rejectedUsers.length}\n\n`;
      
      message += '*Active Breaks*:\n';
      message += `Total: ${activeBreaks.length}\n`;
      
      Object.entries(breakTypeCounts).forEach(([type, count]) => {
        message += `${type}: ${count}\n`;
      });
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error showing system stats:', error);
      this.bot.sendMessage(chatId, 'An error occurred while retrieving system statistics.');
    }
  }
  
  private async listAllUsers(chatId: number) {
    try {
      const users = await storage.getUsers();
      
      if (users.length === 0) {
        this.bot.sendMessage(chatId, 'No users found in the system.');
        return;
      }
      
      // Group users by role
      const usersByRole: Record<string, User[]> = {};
      
      users.forEach(user => {
        if (!usersByRole[user.role]) {
          usersByRole[user.role] = [];
        }
        usersByRole[user.role].push(user);
      });
      
      let message = '*User List*\n\n';
      
      // Add each role group to the message
      Object.entries(usersByRole).forEach(([role, roleUsers]) => {
        message += `*${role}s* (${roleUsers.length}):\n`;
        
        roleUsers.forEach((user, index) => {
          if (index < 5) { // Limit to 5 users per role to avoid message length issues
            message += `- ${user.fullName} (${user.employeeId})\n`;
          } else if (index === 5) {
            message += `... and ${roleUsers.length - 5} more\n`;
          }
        });
        
        message += '\n';
      });
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error listing users:', error);
      this.bot.sendMessage(chatId, 'An error occurred while listing users.');
    }
  }
  
  private async showFinesSummary(chatId: number) {
    try {
      const users = await storage.getUsers();
      let totalFines = 0;
      let employeesWithFines = 0;
      let maxFineAmount = 0;
      let employeeWithMaxFine: User | null = null;
      
      // Calculate fine statistics
      for (const user of users) {
        const userFines = await storage.getTotalFinesByUser(user.id);
        
        if (userFines > 0) {
          employeesWithFines++;
          totalFines += userFines;
          
          if (userFines > maxFineAmount) {
            maxFineAmount = userFines;
            employeeWithMaxFine = user;
          }
        }
      }
      
      // Format the message
      let message = '*Fines Summary*\n\n';
      
      message += `Total fines collected: ${formatCurrency(totalFines)}\n`;
      message += `Employees with fines: ${employeesWithFines}\n`;
      
      if (employeeWithMaxFine) {
        message += `\n*Highest fine*: ${formatCurrency(maxFineAmount)}\n`;
        message += `Employee: ${employeeWithMaxFine.fullName} (${employeeWithMaxFine.employeeId})\n`;
      }
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error showing fines summary:', error);
      this.bot.sendMessage(chatId, 'An error occurred while retrieving fines summary.');
    }
  }
  
  private async createNewUser(chatId: number, userData: any) {
    try {
      // Generate an employee ID and password
      const employeeId = generateEmployeeId();
      const password = generateRandomPassword();
      
      // Create the user
      const newUser = await storage.createUser({
        fullName: userData.name,
        email: userData.email,
        role: userData.role,
        username: userData.username,
        employeeId,
        password: password,
        approvalStatus: userData.role === 'EMPLOYEE' ? 'PENDING' : 'APPROVED'
      });
      
      // Reset state
      this.setUserState(chatId, 'INITIAL');
      
      // Send confirmation message
      let message = `*User Created Successfully*\n\n`;
      message += `Name: ${newUser.fullName}\n`;
      message += `Email: ${newUser.email}\n`;
      message += `Role: ${newUser.role}\n`;
      message += `Username: ${newUser.username}\n`;
      message += `Employee ID: ${newUser.employeeId}\n`;
      message += `Status: ${newUser.approvalStatus}\n\n`;
      
      message += 'This employee ID should be used as their password for the Telegram bot login.';
      
      if (newUser.role === 'EMPLOYEE') {
        message += '\n\nNote: Employee accounts need to be approved by an agent before they can log in.';
      }
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error creating user:', error);
      this.bot.sendMessage(chatId, 'An error occurred while creating the user.');
      this.setUserState(chatId, 'INITIAL');
    }
  }
  
  private async resetUserPassword(chatId: number, employeeId: string) {
    try {
      const user = await storage.getUserByEmployeeId(employeeId);
      
      if (!user) {
        this.bot.sendMessage(chatId, `User with employee ID ${employeeId} not found.`);
        return;
      }
      
      // In a real implementation, we would update the user's password in the database
      // For this prototype, we'll just return the employee ID as the password
      
      let message = `*Password Reset*\n\n`;
      message += `Name: ${user.fullName}\n`;
      message += `Employee ID: ${user.employeeId}\n\n`;
      message += `The employee should use their employee ID as their password for Telegram bot login.`;
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error resetting password:', error);
      this.bot.sendMessage(chatId, 'An error occurred while resetting the user\'s password.');
    }
  }
  
  private async deleteUser(chatId: number, employeeId: string) {
    try {
      const user = await storage.getUserByEmployeeId(employeeId);
      
      if (!user) {
        this.bot.sendMessage(chatId, `User with employee ID ${employeeId} not found.`);
        return;
      }
      
      // Delete the user
      const deleted = await storage.deleteUser(user.id);
      
      // Reset state
      this.setUserState(chatId, 'INITIAL');
      
      if (deleted) {
        this.bot.sendMessage(chatId, `User ${user.fullName} (${user.employeeId}) has been deleted.`);
      } else {
        this.bot.sendMessage(chatId, `Failed to delete user ${user.fullName}.`);
      }
    } catch (error) {
      console.error('Error deleting user:', error);
      this.bot.sendMessage(chatId, 'An error occurred while deleting the user.');
      this.setUserState(chatId, 'INITIAL');
    }
  }
  
  private async searchUsers(chatId: number, query: string) {
    try {
      const users = await storage.getUsers();
      
      // Perform a simple search on name, email, username, or employee ID
      const results = users.filter(user => 
        user.fullName.toLowerCase().includes(query.toLowerCase()) ||
        user.email.toLowerCase().includes(query.toLowerCase()) ||
        user.username.toLowerCase().includes(query.toLowerCase()) ||
        user.employeeId.toLowerCase().includes(query.toLowerCase())
      );
      
      if (results.length === 0) {
        this.bot.sendMessage(chatId, `No users found matching "${query}".`);
        return;
      }
      
      let message = `*Search Results*: ${results.length} user(s) found\n\n`;
      
      results.forEach((user, index) => {
        if (index < 10) { // Limit to 10 results to avoid message length issues
          message += `${index + 1}. ${user.fullName} (${user.employeeId})\n`;
          message += `   Role: ${user.role}, Status: ${user.approvalStatus}\n`;
          message += `   Email: ${user.email}\n\n`;
        } else if (index === 10) {
          message += `... and ${results.length - 10} more\n`;
        }
      });
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error searching users:', error);
      this.bot.sendMessage(chatId, 'An error occurred while searching for users.');
    }
  }
  
  private async listActiveBreaks(chatId: number) {
    try {
      const activeBreaks = await storage.getActiveBreaks();
      
      if (activeBreaks.length === 0) {
        this.bot.sendMessage(chatId, 'No active breaks found.');
        return;
      }
      
      let message = '*Active Breaks*:\n\n';
      
      for (const breakItem of activeBreaks) {
        const user = await storage.getUser(breakItem.userId);
        if (!user) continue;
        
        const startTime = new Date(breakItem.startTime);
        const now = new Date();
        const duration = Math.floor((now.getTime() - startTime.getTime()) / 60000); // in minutes
        const limit = BreakLimits[breakItem.breakType as keyof typeof BreakLimits];
        
        message += `${user.fullName} (${user.employeeId})\n`;
        message += `Type: ${breakItem.breakType}\n`;
        message += `Started: ${startTime.toLocaleTimeString()}\n`;
        message += `Duration: ${duration} minutes / ${limit} minutes\n`;
        
        if (duration > limit) {
          const overtime = duration - limit;
          message += `⚠️ *Overtime*: ${overtime} minutes\n`;
          message += `Estimated fine: ${formatCurrency(10 + overtime)}\n`;
        }
        
        message += '\n';
      }
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error listing active breaks:', error);
      this.bot.sendMessage(chatId, 'An error occurred while listing active breaks.');
    }
  }
}