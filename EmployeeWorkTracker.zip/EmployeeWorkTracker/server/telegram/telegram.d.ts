declare module 'node-telegram-bot-api' {
  export interface Message {
    message_id: number;
    from?: User;
    date: number;
    chat: Chat;
    text?: string;
    entities?: MessageEntity[];
    [key: string]: any;
  }

  export interface User {
    id: number;
    first_name: string;
    last_name?: string;
    username?: string;
    [key: string]: any;
  }

  export interface Chat {
    id: number;
    type: 'private' | 'group' | 'supergroup' | 'channel';
    title?: string;
    username?: string;
    first_name?: string;
    last_name?: string;
    [key: string]: any;
  }

  export interface MessageEntity {
    type: string;
    offset: number;
    length: number;
    url?: string;
    user?: User;
    [key: string]: any;
  }

  export interface SendMessageOptions {
    parse_mode?: 'Markdown' | 'HTML';
    disable_web_page_preview?: boolean;
    disable_notification?: boolean;
    reply_to_message_id?: number;
    reply_markup?: any;
    [key: string]: any;
  }

  export default class TelegramBot {
    constructor(token: string, options?: { polling?: boolean | object });
    
    onText(regexp: RegExp, callback: (msg: Message, match?: RegExpExecArray) => void): void;
    on(event: string, callback: (msg: Message) => void): void;
    sendMessage(chatId: number | string, text: string, options?: SendMessageOptions): Promise<Message>;
    
    // Add other methods as needed
    [key: string]: any;
  }
}