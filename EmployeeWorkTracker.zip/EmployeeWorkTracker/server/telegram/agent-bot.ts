import TelegramBot from 'node-telegram-bot-api';
import { BaseTelegramBot } from './base-bot';
import { storage } from '../storage';
import { User, Break, BreakType, BreakLimits, UserRole } from '@shared/schema';
import { formatDate, formatCurrency } from '../utils';

export class AgentTelegramBot extends BaseTelegramBot {
  constructor(token: string) {
    super(token, 'Agent');
    this.startSessionCleanup();
  }
  
  protected registerHandlers() {
    // Register specific handlers for agent bot
    this.bot.onText(/\/employees/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.listEmployees(chatId);
    });
    
    this.bot.onText(/\/pending/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.listPendingApprovals(chatId);
    });
    
    this.bot.onText(/\/approve (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      const employeeId = match?.[1];
      if (!employeeId) {
        this.bot.sendMessage(chatId, 'Please provide an employee ID to approve.');
        return;
      }
      
      await this.approveEmployee(chatId, employeeId);
    });
    
    this.bot.onText(/\/reject (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      const employeeId = match?.[1];
      if (!employeeId) {
        this.bot.sendMessage(chatId, 'Please provide an employee ID to reject.');
        return;
      }
      
      await this.rejectEmployee(chatId, employeeId);
    });
    
    this.bot.onText(/\/active/, async (msg) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      await this.listActiveBreaks(chatId);
    });
    
    this.bot.onText(/\/employee (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      const employeeId = match?.[1];
      if (!employeeId) {
        this.bot.sendMessage(chatId, 'Please provide an employee ID to view details.');
        return;
      }
      
      await this.viewEmployeeDetails(chatId, employeeId);
    });
    
    this.bot.onText(/\/breaks (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      if (!this.ensureAuthenticated(chatId)) return;
      
      const employeeId = match?.[1];
      if (!employeeId) {
        this.bot.sendMessage(chatId, 'Please provide an employee ID to view break history.');
        return;
      }
      
      await this.viewEmployeeBreaks(chatId, employeeId);
    });
  }
  
  protected sendHelpMessage(chatId: number) {
    const helpMessage = `
*Agent Bot Commands*:

/start - Start the bot and authenticate
/employees - List all employees
/pending - List users pending approval
/approve EMPLOYEE_ID - Approve a pending employee
/reject EMPLOYEE_ID - Reject a pending employee
/active - List all active breaks
/employee EMPLOYEE_ID - View employee details
/breaks EMPLOYEE_ID - View employee break history
/help - Show this help message
/logout - Log out from the bot
`;
    
    this.bot.sendMessage(chatId, helpMessage, { parse_mode: 'Markdown' });
  }
  
  protected async handleMessage(chatId: number, msg: any) {
    // Handle messages based on the current state
    const stateInfo = this.getUserState(chatId);
    
    if (!stateInfo) {
      this.bot.sendMessage(chatId, 'Please use one of the available commands. Type /help to see options.');
      return;
    }
    
    const { state, data } = stateInfo;
    
    // Agent bot doesn't need additional message handling beyond commands for now
    this.bot.sendMessage(chatId, 'Please use one of the available commands. Type /help to see options.');
  }
  
  protected async authenticateUser(chatId: number, password: string): Promise<User | null> {
    try {
      // Get agent password from environment variable with fallback to default
      const agentPassword = process.env.TELEGRAM_AGENT_PASSWORD || 'agent123';
      
      // Compare provided password with the configured one
      if (password === agentPassword) {
        // If password matches, return the first agent user
        const agents = await storage.getUsersByRole(UserRole.AGENT);
        
        if (agents.length > 0) {
          return agents[0];
        }
        
        // If no agents exist, create a default one (for testing)
        const newAgent = await storage.createUser({
          fullName: 'Default Agent',
          email: 'agent@example.com',
          role: UserRole.AGENT,
          username: 'default_agent',
          employeeId: 'AGENT001',
          approvalStatus: 'APPROVED',
          password: 'agent123'
        });
        
        return newAgent;
      }
      
      return null;
    } catch (error) {
      console.error('Error authenticating agent:', error);
      return null;
    }
  }
  
  // Helper methods
  
  private async listEmployees(chatId: number) {
    try {
      const employees = await storage.getUsersByRole('EMPLOYEE');
      
      if (employees.length === 0) {
        this.bot.sendMessage(chatId, 'No employees found.');
        return;
      }
      
      let message = '*Employees*:\n\n';
      
      employees.forEach((employee, index) => {
        message += `${index + 1}. ${employee.fullName} (${employee.employeeId})\n`;
        message += `   Status: ${employee.approvalStatus}\n\n`;
      });
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error listing employees:', error);
      this.bot.sendMessage(chatId, 'An error occurred while listing employees.');
    }
  }
  
  private async listPendingApprovals(chatId: number) {
    try {
      const pendingUsers = await storage.getUsersByApprovalStatus('PENDING');
      
      if (pendingUsers.length === 0) {
        this.bot.sendMessage(chatId, 'No pending approvals.');
        return;
      }
      
      let message = '*Pending Approvals*:\n\n';
      
      pendingUsers.forEach((user, index) => {
        message += `${index + 1}. ${user.fullName} (${user.employeeId})\n`;
        message += `   Email: ${user.email}\n`;
        message += `   Role: ${user.role}\n\n`;
        message += `   Use /approve ${user.employeeId} to approve or /reject ${user.employeeId} to reject\n\n`;
      });
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error listing pending approvals:', error);
      this.bot.sendMessage(chatId, 'An error occurred while listing pending approvals.');
    }
  }
  
  private async approveEmployee(chatId: number, employeeId: string) {
    try {
      const user = await storage.getUserByEmployeeId(employeeId);
      
      if (!user) {
        this.bot.sendMessage(chatId, `User with employee ID ${employeeId} not found.`);
        return;
      }
      
      if (user.approvalStatus === 'APPROVED') {
        this.bot.sendMessage(chatId, `User ${user.fullName} is already approved.`);
        return;
      }
      
      // Update user approval status
      const updatedUser = await storage.updateUser(user.id, {
        approvalStatus: 'APPROVED'
      });
      
      this.bot.sendMessage(chatId, `User ${updatedUser?.fullName} (${updatedUser?.employeeId}) has been approved.`);
    } catch (error) {
      console.error('Error approving employee:', error);
      this.bot.sendMessage(chatId, 'An error occurred while approving the employee.');
    }
  }
  
  private async rejectEmployee(chatId: number, employeeId: string) {
    try {
      const user = await storage.getUserByEmployeeId(employeeId);
      
      if (!user) {
        this.bot.sendMessage(chatId, `User with employee ID ${employeeId} not found.`);
        return;
      }
      
      if (user.approvalStatus === 'REJECTED') {
        this.bot.sendMessage(chatId, `User ${user.fullName} is already rejected.`);
        return;
      }
      
      // Update user approval status
      const updatedUser = await storage.updateUser(user.id, {
        approvalStatus: 'REJECTED'
      });
      
      this.bot.sendMessage(chatId, `User ${updatedUser?.fullName} (${updatedUser?.employeeId}) has been rejected.`);
    } catch (error) {
      console.error('Error rejecting employee:', error);
      this.bot.sendMessage(chatId, 'An error occurred while rejecting the employee.');
    }
  }
  
  private async listActiveBreaks(chatId: number) {
    try {
      const activeBreaks = await storage.getActiveBreaks();
      
      if (activeBreaks.length === 0) {
        this.bot.sendMessage(chatId, 'No active breaks found.');
        return;
      }
      
      let message = '*Active Breaks*:\n\n';
      
      for (const breakItem of activeBreaks) {
        const user = await storage.getUser(breakItem.userId);
        if (!user) continue;
        
        const startTime = new Date(breakItem.startTime);
        const now = new Date();
        const duration = Math.floor((now.getTime() - startTime.getTime()) / 60000); // in minutes
        const limit = BreakLimits[breakItem.breakType as keyof typeof BreakLimits];
        
        message += `${user.fullName} (${user.employeeId})\n`;
        message += `Type: ${breakItem.breakType}\n`;
        message += `Started: ${startTime.toLocaleTimeString()}\n`;
        message += `Duration: ${duration} minutes / ${limit} minutes\n`;
        
        if (duration > limit) {
          const overtime = duration - limit;
          message += `⚠️ *Overtime*: ${overtime} minutes\n`;
        }
        
        message += '\n';
      }
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error listing active breaks:', error);
      this.bot.sendMessage(chatId, 'An error occurred while listing active breaks.');
    }
  }
  
  private async viewEmployeeDetails(chatId: number, employeeId: string) {
    try {
      const user = await storage.getUserByEmployeeId(employeeId);
      
      if (!user) {
        this.bot.sendMessage(chatId, `User with employee ID ${employeeId} not found.`);
        return;
      }
      
      // Get user's active break
      const activeBreak = await storage.getUserActiveBreak(user.id);
      
      // Get total fines
      const totalFines = await storage.getTotalFinesByUser(user.id);
      const monthlyFines = await storage.getMonthlyFinesByUser(user.id);
      
      let message = `*Employee Details*: ${user.fullName}\n\n`;
      message += `Employee ID: ${user.employeeId}\n`;
      message += `Email: ${user.email}\n`;
      message += `Status: ${user.approvalStatus}\n`;
      message += `Total Fines: ${formatCurrency(totalFines)}\n`;
      message += `Monthly Fines: ${formatCurrency(monthlyFines)}\n\n`;
      
      if (activeBreak) {
        const startTime = new Date(activeBreak.startTime);
        const now = new Date();
        const duration = Math.floor((now.getTime() - startTime.getTime()) / 60000); // in minutes
        const limit = BreakLimits[activeBreak.breakType as keyof typeof BreakLimits];
        
        message += `*Current Break*:\n`;
        message += `Type: ${activeBreak.breakType}\n`;
        message += `Started: ${startTime.toLocaleTimeString()}\n`;
        message += `Duration: ${duration} minutes / ${limit} minutes\n`;
        
        if (duration > limit) {
          const overtime = duration - limit;
          message += `⚠️ *Overtime*: ${overtime} minutes\n`;
        }
      } else {
        message += `*Break Status*: No active breaks\n`;
      }
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error viewing employee details:', error);
      this.bot.sendMessage(chatId, 'An error occurred while viewing employee details.');
    }
  }
  
  private async viewEmployeeBreaks(chatId: number, employeeId: string) {
    try {
      const user = await storage.getUserByEmployeeId(employeeId);
      
      if (!user) {
        this.bot.sendMessage(chatId, `User with employee ID ${employeeId} not found.`);
        return;
      }
      
      // Get user's breaks
      const breaks = await storage.getBreaksByUser(user.id);
      
      if (breaks.length === 0) {
        this.bot.sendMessage(chatId, `No breaks found for ${user.fullName}.`);
        return;
      }
      
      let message = `*Break History*: ${user.fullName}\n\n`;
      
      // Sort breaks by start time, most recent first
      breaks.sort((a, b) => 
        new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
      );
      
      // Show the 10 most recent breaks
      const recentBreaks = breaks.slice(0, 10);
      
      recentBreaks.forEach((breakItem, index) => {
        const startTime = new Date(breakItem.startTime);
        const endTime = breakItem.endTime ? new Date(breakItem.endTime) : null;
        
        message += `${index + 1}. ${breakItem.breakType} Break - ${formatDate(startTime)}\n`;
        message += `   Status: ${endTime ? 'Completed' : 'In Progress'}\n`;
        
        if (endTime) {
          const duration = breakItem.duration || 0;
          const limit = BreakLimits[breakItem.breakType as keyof typeof BreakLimits];
          
          message += `   Duration: ${duration} minutes / ${limit} minutes\n`;
          
          if (duration > limit) {
            const overtime = duration - limit;
            message += `   ⚠️ Overtime: ${overtime} minutes\n`;
          }
        } else {
          message += `   In progress...\n`;
        }
        
        message += '\n';
      });
      
      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error viewing employee breaks:', error);
      this.bot.sendMessage(chatId, 'An error occurred while viewing employee breaks.');
    }
  }
}