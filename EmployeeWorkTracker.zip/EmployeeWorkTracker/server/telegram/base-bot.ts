import TelegramBot from 'node-telegram-bot-api';
import { storage } from '../storage';
import { User, UserRole } from '@shared/schema';

export abstract class BaseTelegramBot {
  // Initialize with dummy bot to satisfy TypeScript initially
  protected bot: TelegramBot = {} as TelegramBot;
  protected botName: string = '';
  // Flag to track if the bot is already restarting to prevent multiple restarts
  private isRestarting: boolean = false;
  
  // Create dummy bot with stub methods to prevent errors if bot initialization fails
  private createDummyBot(): TelegramBot {
    const dummyBot = {
      on: () => {},
      onText: () => {},
      sendMessage: () => Promise.resolve({} as any)
    } as unknown as TelegramBot;
    return dummyBot;
  }
  
  // Map to store active user sessions with password authentication status
  protected userSessions: Map<number, { 
    authenticated: boolean;
    userId?: number;
    lastCommandTime: number;
    currentState?: string;
    tempData?: any;
  }> = new Map();
  
  // Session timeout in milliseconds (30 minutes)
  protected readonly SESSION_TIMEOUT = 30 * 60 * 1000;

  constructor(token: string, botName: string) {
    this.botName = botName;
    
    try {
      this.bot = new TelegramBot(token, { polling: true });
      
      // Add specific error handling for polling errors
      this.bot.on('polling_error', (error) => {
        console.error(`${this.botName} bot polling error:`, error.code, error.message);
        
        if (error.code === 'ETELEGRAM' && error.message.includes('404 Not Found')) {
          console.error(`${this.botName} bot token appears to be invalid. Please check the token and regenerate it if necessary.`);
        }
        
        // Handle the 409 Conflict error which happens when multiple instances of the bot are running
        if (error.code === 'ETELEGRAM' && error.message.includes('409 Conflict') && !this.isRestarting) {
          this.isRestarting = true; // Prevent multiple restarts
          console.warn(`${this.botName} bot: Detected conflict with another instance. This is normal during restarts.`);
          
          // Stop polling on this instance to avoid more conflicts
          try {
            this.bot.stopPolling();
            console.log(`${this.botName} bot: Stopped polling to avoid conflicts.`);
            
            // Try to restart polling after a short delay
            setTimeout(() => {
              try {
                if (this.bot && typeof this.bot.startPolling === 'function') {
                  this.bot.startPolling();
                  console.log(`${this.botName} bot: Restarted polling after conflict.`);
                  
                  // Reset flag after successful restart
                  setTimeout(() => {
                    this.isRestarting = false;
                  }, 5000);
                }
              } catch (restartError) {
                console.error(`${this.botName} bot: Failed to restart polling:`, restartError);
                this.isRestarting = false; // Reset flag on error
              }
            }, 15000); // Wait 15 seconds before attempting to restart
          } catch (stopError) {
            console.error(`${this.botName} bot: Error stopping polling:`, stopError);
            this.isRestarting = false; // Reset flag on error
          }
        }
      });
      
      // Register common handlers
      this.registerCommonHandlers();
      
      // Register bot-specific handlers
      this.registerHandlers();
      
      console.log(`${this.botName} bot is running...`);
    } catch (error) {
      console.error(`Error initializing ${this.botName} bot:`, error);
      
      // Create a dummy bot to prevent null errors
      this.bot = this.createDummyBot();
    }
  }
  
  // Clean up old sessions periodically
  protected startSessionCleanup() {
    setInterval(() => {
      const now = Date.now();
      // Convert entries to array to avoid iterator issues
      Array.from(this.userSessions.entries()).forEach(([chatId, session]) => {
        if (now - session.lastCommandTime > this.SESSION_TIMEOUT) {
          this.userSessions.delete(chatId);
        }
      });
    }, 5 * 60 * 1000); // Run every 5 minutes
  }
  
  protected registerCommonHandlers() {
    // Start command handler
    this.bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      this.resetSession(chatId);
      
      // Different welcome messages based on bot type
      if (this.botName === 'Employee') {
        this.bot.sendMessage(chatId, 
          `Welcome to the ${this.botName} bot! Please enter your employee ID to continue.`
        );
      } else {
        this.bot.sendMessage(chatId, 
          `Welcome to the ${this.botName} bot! Please enter your password to authenticate.`
        );
      }
    });
    
    // Help command handler
    this.bot.onText(/\/help/, (msg) => {
      const chatId = msg.chat.id;
      this.updateSession(chatId);
      
      // Check if user is authenticated
      const session = this.userSessions.get(chatId);
      if (!session?.authenticated) {
        this.bot.sendMessage(chatId, 'Please authenticate first by using /start command.');
        return;
      }
      
      this.sendHelpMessage(chatId);
    });
    
    // Logout command handler
    this.bot.onText(/\/logout/, (msg) => {
      const chatId = msg.chat.id;
      this.resetSession(chatId);
      this.bot.sendMessage(chatId, 'You have been logged out. Type /start to login again.');
    });
    
    // Handle all non-command messages for authentication or specific bot functions
    this.bot.on('message', (msg) => {
      // Skip if it's a command
      if (msg.text && msg.text.startsWith('/')) {
        return;
      }
      
      const chatId = msg.chat.id;
      const session = this.userSessions.get(chatId);
      
      // Check if we have an active session
      if (!session) {
        this.bot.sendMessage(chatId, 'Please start a new session with /start command.');
        return;
      }
      
      this.updateSession(chatId);
      
      // If not authenticated, try to authenticate
      if (!session.authenticated) {
        this.handleAuthentication(chatId, msg.text || '');
        return;
      }
      
      // Handle the message based on the current state
      this.handleMessage(chatId, msg);
    });
  }
  
  // To be implemented by specific bot implementations
  protected abstract registerHandlers(): void;
  
  // To be implemented by specific bot implementations
  protected abstract sendHelpMessage(chatId: number): void;
  
  // To be implemented by specific bot implementations
  protected abstract handleMessage(chatId: number, msg: any): void;
  
  // To be implemented by specific bot implementations
  protected abstract authenticateUser(chatId: number, password: string): Promise<User | null>;
  
  // Handle authentication flow
  protected async handleAuthentication(chatId: number, password: string) {
    try {
      const user = await this.authenticateUser(chatId, password);
      
      if (user) {
        const session = this.userSessions.get(chatId);
        if (session) {
          session.authenticated = true;
          session.userId = user.id;
          this.userSessions.set(chatId, session);
        }
        
        this.bot.sendMessage(chatId, `Authentication successful! Welcome, ${user.fullName}.`);
        this.sendHelpMessage(chatId);
      } else {
        // Different error messages based on bot type
        if (this.botName === 'Employee') {
          this.bot.sendMessage(chatId, 'Invalid employee ID. Please try again or use /start to restart.');
        } else {
          this.bot.sendMessage(chatId, 'Invalid password. Please try again or use /start to restart.');
        }
      }
    } catch (error) {
      console.error(`Authentication error for ${this.botName}:`, error);
      this.bot.sendMessage(chatId, 'An error occurred during authentication. Please try again later.');
    }
  }
  
  // Update user session last activity time
  protected updateSession(chatId: number) {
    const session = this.userSessions.get(chatId);
    if (session) {
      session.lastCommandTime = Date.now();
      this.userSessions.set(chatId, session);
    } else {
      this.resetSession(chatId);
    }
  }
  
  // Reset or create a new session
  protected resetSession(chatId: number) {
    this.userSessions.set(chatId, {
      authenticated: false,
      lastCommandTime: Date.now(),
      currentState: 'INITIAL'
    });
  }
  
  // Change the current state of a user session
  protected setUserState(chatId: number, state: string, tempData?: any) {
    const session = this.userSessions.get(chatId);
    if (session) {
      session.currentState = state;
      if (tempData !== undefined) {
        session.tempData = tempData;
      }
      this.userSessions.set(chatId, session);
    }
  }
  
  // Get the current state of a user session
  protected getUserState(chatId: number): { state: string, data: any } | null {
    const session = this.userSessions.get(chatId);
    if (session) {
      return { state: session.currentState || 'INITIAL', data: session.tempData };
    }
    return null;
  }
  
  // Get user ID from session
  protected getUserId(chatId: number): number | null {
    const session = this.userSessions.get(chatId);
    return session?.userId || null;
  }
  
  // Check if user is authenticated
  protected isAuthenticated(chatId: number): boolean {
    const session = this.userSessions.get(chatId);
    return !!session?.authenticated;
  }
  
  // Ensure user is authenticated before proceeding
  protected ensureAuthenticated(chatId: number): boolean {
    if (!this.isAuthenticated(chatId)) {
      this.bot.sendMessage(chatId, 'You need to authenticate first. Please use /start command.');
      return false;
    }
    return true;
  }
  
  // Method to send a notification to a user via their Telegram ID
  public async sendNotificationToUser(telegramId: string, message: string): Promise<boolean> {
    if (!telegramId) {
      console.log(`Cannot send notification: No Telegram ID provided`);
      return false;
    }
    
    try {
      // Convert telegramId to a number
      const chatId = Number(telegramId);
      if (isNaN(chatId)) {
        console.log(`Invalid Telegram ID format: ${telegramId}`);
        return false;
      }
      
      await this.bot.sendMessage(chatId, message);
      console.log(`Notification sent to Telegram ID: ${telegramId}`);
      return true;
    } catch (error) {
      console.error(`Failed to send notification to Telegram ID ${telegramId}:`, error);
      return false;
    }
  }
  
  // Method to properly shut down the bot
  public shutdown(): void {
    try {
      console.log(`Shutting down ${this.botName} bot...`);
      
      // Cancel any pending operations
      this.isRestarting = true;
      
      // Stop polling to prevent more webhook requests
      if (this.bot && typeof this.bot.stopPolling === 'function') {
        this.bot.stopPolling();
        console.log(`${this.botName} bot polling stopped.`);
      }
      
      // Clear session cleanup interval if it exists
      // (Note: we don't have a reference to the interval timer here,
      // so if needed we could store it as a class property when created)
      
      console.log(`${this.botName} bot has been shut down.`);
    } catch (error) {
      console.error(`Error shutting down ${this.botName} bot:`, error);
    }
  }
}