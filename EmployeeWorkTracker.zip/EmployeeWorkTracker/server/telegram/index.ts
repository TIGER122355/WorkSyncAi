import { EmployeeTelegramBot } from './employee-bot';
import { AgentTelegramBot } from './agent-bot';
import { AdminTelegramBot } from './admin-bot';

// Helper function to validate Telegram tokens (should match pattern like 123456789:ABCDefGhIJKlmnOPQRstUVwxyZ)
function isValidTelegramToken(token: string): boolean {
  const telegramTokenPattern = /^\d+:[A-Za-z0-9_-]+$/;
  return telegramTokenPattern.test(token);
}

// Override with known correct values to avoid environment variable issues
// This is a critical workaround for Replit environment variable inconsistencies
console.log('Setting up Telegram bot tokens with known correct values (ignoring environment variables)');

// Directly use hardcoded values since environment variables are not reliable
const EMPLOYEE_BOT_TOKEN = '7569759588:AAFT_T8_qmyx8AgaItWol7efINAsPfDIVqI';
const AGENT_BOT_TOKEN = '7914697763:AAEhHcaFnjPBKhp4WDL0Oc4bayLW4FWurWU';
const ADMIN_BOT_TOKEN = '7611852216:AAElb5YNQezpEop0z8VB95BOQAgCw5TayII';

// Set bot passwords - use environment variable if available, otherwise use default
// Ensure these match the passwords in the .env file
process.env.TELEGRAM_ADMIN_PASSWORD = process.env.TELEGRAM_ADMIN_PASSWORD || 'SecureAdminPass123!';
process.env.TELEGRAM_AGENT_PASSWORD = process.env.TELEGRAM_AGENT_PASSWORD || 'SecureAgentPass456!';
// No password is needed for the employee bot - it uses employee ID only

// Validate tokens before using them
console.log('EMPLOYEE_BOT_TOKEN is valid:', isValidTelegramToken(EMPLOYEE_BOT_TOKEN));
console.log('AGENT_BOT_TOKEN is valid:', isValidTelegramToken(AGENT_BOT_TOKEN));
console.log('ADMIN_BOT_TOKEN is valid:', isValidTelegramToken(ADMIN_BOT_TOKEN));

// Log the tokens and perform validation to check if they're loaded properly
console.log('Environment variables loaded:');

// Log bot password statuses
console.log('- TELEGRAM_ADMIN_PASSWORD:', process.env.TELEGRAM_ADMIN_PASSWORD ? 'Configured' : 'Not configured (using default)');
console.log('- TELEGRAM_AGENT_PASSWORD:', process.env.TELEGRAM_AGENT_PASSWORD ? 'Configured' : 'Not configured (using default)');
console.log('- EMPLOYEE BOT: Password-free (uses employee ID only)');

// Check Employee Bot token
if (!EMPLOYEE_BOT_TOKEN) {
  console.error('ERROR: TELEGRAM_EMPLOYEE_BOT_TOKEN is missing in environment variables');
} else if (!isValidTelegramToken(EMPLOYEE_BOT_TOKEN)) {
  console.error('ERROR: TELEGRAM_EMPLOYEE_BOT_TOKEN is not a valid Telegram bot token format');
  console.error('Current value starts with:', EMPLOYEE_BOT_TOKEN.substring(0, 10));
} else {
  console.log('- TELEGRAM_EMPLOYEE_BOT_TOKEN:', `${EMPLOYEE_BOT_TOKEN.substring(0, 10)}...`);
}

// Check Agent Bot token
if (!AGENT_BOT_TOKEN) {
  console.error('ERROR: TELEGRAM_AGENT_BOT_TOKEN is missing in environment variables');
} else if (!isValidTelegramToken(AGENT_BOT_TOKEN)) {
  console.error('ERROR: TELEGRAM_AGENT_BOT_TOKEN is not a valid Telegram bot token format');
  console.error('Current value starts with:', AGENT_BOT_TOKEN.substring(0, 10));
} else {
  console.log('- TELEGRAM_AGENT_BOT_TOKEN:', `${AGENT_BOT_TOKEN.substring(0, 10)}...`);
}

// Check Admin Bot token
if (!ADMIN_BOT_TOKEN) {
  console.error('ERROR: TELEGRAM_ADMIN_BOT_TOKEN is missing in environment variables');
} else if (!isValidTelegramToken(ADMIN_BOT_TOKEN)) {
  console.error('ERROR: TELEGRAM_ADMIN_BOT_TOKEN is not a valid Telegram bot token format');
  console.error('Current value starts with:', ADMIN_BOT_TOKEN.substring(0, 10));
} else {
  console.log('- TELEGRAM_ADMIN_BOT_TOKEN:', `${ADMIN_BOT_TOKEN.substring(0, 10)}...`);
}

// Export bot instances so they can be accessed from other modules
export let employeeBot: EmployeeTelegramBot | null = null;
export let agentBot: AgentTelegramBot | null = null;
export let adminBot: AdminTelegramBot | null = null;

/**
 * Initialize all Telegram bots
 */
export function initializeTelegramBots(): { 
  employeeBot: EmployeeTelegramBot | null, 
  agentBot: AgentTelegramBot | null, 
  adminBot: AdminTelegramBot | null 
} {
  console.log('Initializing Telegram bots...');
  
  // Initialize Employee Bot if token is available and valid
  if (EMPLOYEE_BOT_TOKEN && isValidTelegramToken(EMPLOYEE_BOT_TOKEN)) {
    try {
      console.log('Employee Bot token:', EMPLOYEE_BOT_TOKEN.substring(0, 10) + '...');
      employeeBot = new EmployeeTelegramBot(EMPLOYEE_BOT_TOKEN);
      console.log('Employee Bot initialized successfully');
    } catch (error) {
      console.error('Error initializing Employee Bot:', error);
    }
  } else {
    console.warn('Employee Bot not initialized: Missing or invalid TELEGRAM_EMPLOYEE_BOT_TOKEN');
  }
  
  // Initialize Agent Bot if token is available and valid
  if (AGENT_BOT_TOKEN && isValidTelegramToken(AGENT_BOT_TOKEN)) {
    try {
      console.log('Agent Bot token:', AGENT_BOT_TOKEN.substring(0, 10) + '...');
      agentBot = new AgentTelegramBot(AGENT_BOT_TOKEN);
      console.log('Agent Bot initialized successfully');
    } catch (error) {
      console.error('Error initializing Agent Bot:', error);
    }
  } else {
    console.warn('Agent Bot not initialized: Missing or invalid TELEGRAM_AGENT_BOT_TOKEN');
  }
  
  // Initialize Admin Bot if token is available and valid
  if (ADMIN_BOT_TOKEN && isValidTelegramToken(ADMIN_BOT_TOKEN)) {
    try {
      console.log('Admin Bot token:', ADMIN_BOT_TOKEN.substring(0, 10) + '...');
      adminBot = new AdminTelegramBot(ADMIN_BOT_TOKEN);
      console.log('Admin Bot initialized successfully');
    } catch (error) {
      console.error('Error initializing Admin Bot:', error);
    }
  } else {
    console.warn('Admin Bot not initialized: Missing or invalid TELEGRAM_ADMIN_BOT_TOKEN');
  }
  
  return { employeeBot, agentBot, adminBot };
}

/**
 * Helper function to send a notification to a user via their Telegram ID
 * This will try each bot in order until one succeeds
 */
export async function sendTelegramNotification(telegramId: string, message: string): Promise<boolean> {
  if (!telegramId) {
    console.log('Cannot send notification: No Telegram ID provided');
    return false;
  }

  // Try with employee bot first
  if (employeeBot) {
    try {
      const success = await employeeBot.sendNotificationToUser(telegramId, message);
      if (success) return true;
    } catch (error) {
      console.error('Error sending notification with employee bot:', error);
    }
  }

  // Try with agent bot next
  if (agentBot) {
    try {
      const success = await agentBot.sendNotificationToUser(telegramId, message);
      if (success) return true;
    } catch (error) {
      console.error('Error sending notification with agent bot:', error);
    }
  }

  // Try with admin bot last
  if (adminBot) {
    try {
      const success = await adminBot.sendNotificationToUser(telegramId, message);
      if (success) return true;
    } catch (error) {
      console.error('Error sending notification with admin bot:', error);
    }
  }

  console.log(`Failed to send notification to Telegram ID ${telegramId} using all available bots`);
  return false;
}

export { EmployeeTelegramBot, AgentTelegramBot, AdminTelegramBot };