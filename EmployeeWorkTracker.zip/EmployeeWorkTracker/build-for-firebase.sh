#!/bin/bash

# Script to build and prepare the application for Firebase deployment

echo "Building application for Firebase deployment..."

# Clear previous build files
rm -rf dist

# Run the build script
npm run build

# Copy necessary files to the dist directory
cp firebase.json dist/
cp .firebaserc dist/

echo "Build completed successfully!"
echo "To deploy to Firebase, run these commands on your local machine:"
echo "- firebase login"
echo "- firebase deploy"
echo ""
echo "For more detailed instructions, refer to FIREBASE_DEPLOYMENT_GUIDE.md"