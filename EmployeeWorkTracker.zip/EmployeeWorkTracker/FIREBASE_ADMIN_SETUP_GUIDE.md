# Firebase Admin SDK Setup Guide

This guide will help you set up the Firebase Admin SDK for your WorkSync AI application.

## Prerequisites

1. A Firebase project created in the [Firebase Console](https://console.firebase.google.com/)
2. Google authentication enabled in your Firebase project

## Generating a Service Account Key

1. Go to the [Firebase Console](https://console.firebase.google.com/)
2. Select your project: `worksync-ai-49e80`
3. Click on the gear icon (⚙️) next to "Project Overview" to go to Project settings
4. Go to the "Service accounts" tab
5. Click on "Generate new private key" button
6. Save the downloaded JSON file (it contains your service account credentials)

## Adding the Service Account Key to the Project

1. Rename the downloaded JSON file to `firebase-service-account.json`
2. Place the file in the `server` directory of your project

## Enabling the Firebase Admin SDK

Once you've added the service account key, the Firebase Admin SDK will be automatically enabled in your application. The server will verify Firebase ID tokens for proper authentication.

## Verifying the Setup

1. Restart the application
2. Try signing in with Google
3. The server should now properly verify your Firebase ID token and create or update a user in the database

## Important Security Notes

- **Never commit the service account key to version control**
- The service account key grants admin privileges to your Firebase project
- Keep the file secure and treat it like a password
- For production, consider using environment variables or secret management services to store the key

## Troubleshooting

If you encounter issues with the Firebase Admin SDK:

1. Check the server logs for any specific error messages
2. Verify that the service account key file is properly formatted and contains all required fields
3. Ensure that the Firebase project ID in the service account key matches the one in your Firebase configuration
4. Check that Google authentication is enabled in your Firebase project
5. Make sure the service account has the necessary permissions in Firebase

## Next Steps

Once the Firebase Admin SDK is properly set up, you can:

1. Verify Firebase ID tokens on the server
2. Access Firebase services (Auth, Firestore, etc.) from the server
3. Perform administrative operations on behalf of users