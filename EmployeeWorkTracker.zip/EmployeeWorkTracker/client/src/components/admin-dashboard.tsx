import { useState } from "react";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { StatsResponse, UsersResponse } from "@/lib/queryClient";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest, getQueryFn } from "@/lib/queryClient";
import { User, UserRole, insertUserSchema } from "@shared/schema";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
// Remove duplicate zod import since it's likely imported elsewhere

import { 
  LogOut, 
  Search, 
  Plus, 
  Eye, 
  Edit, 
  Trash2, 
  FileDown, 
  CheckCircle, 
  XCircle,
  Users,
  Timer,
  FileCheck,
  DollarSign
} from "lucide-react";

interface AdminDashboardProps {
  user: User;
  onLogout: () => void;
}

// Form schema for adding new user
const createUserSchema = insertUserSchema.extend({
  role: z.enum([UserRole.ADMIN, UserRole.AGENT, UserRole.EMPLOYEE], {
    required_error: "Please select a user role",
  }),
  department: z.string().optional(),
  telegramId: z.string().optional(),
});

type CreateUserFormValues = z.infer<typeof createUserSchema>;

// Create user mutation
const createUserMutation = useMutation({
  mutationFn: async (data: CreateUserFormValues) => {
    const response = await apiRequest('POST', '/api/users/register', data, true);
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to create user');
    }
    return response.json();
  },
  onSuccess: () => {
    toast({
      title: "Success",
      description: "User created successfully",
    });
    setDialogOpen(false);
    form.reset();
    // Refresh user lists
    queryClient.invalidateQueries({ queryKey: ['/api/users/role/employee'] });
    queryClient.invalidateQueries({ queryKey: ['/api/users/role/agent'] });
    queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
  },
  onError: (error) => {
    toast({
      variant: "destructive",
      title: "Error creating user",
      description: error instanceof Error ? error.message : "An error occurred",
    });
  }
});

// Handle form submission
const onSubmit = (data: CreateUserFormValues) => {
  createUserMutation.mutate(data);
};

export function AdminDashboard({ user, onLogout }: AdminDashboardProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("employees");
  const [dialogOpen, setDialogOpen] = useState(false);
  
  // Fetch stats for dashboard
  const { data: statsData } = useQuery<StatsResponse>({
    queryKey: ['/api/stats'],
    queryFn: getQueryFn({ 
      on401: "throw",
      includeToken: true 
    }),
  });
  
  // Fetch employees
  const { data: employeesData } = useQuery<UsersResponse>({
    queryKey: ['/api/users/role/employee'],
    queryFn: getQueryFn({ 
      on401: "throw",
      includeToken: true 
    }),
  });
  
  // Fetch agents
  const { data: agentsData } = useQuery<UsersResponse>({
    queryKey: ['/api/users/role/agent'],
    queryFn: getQueryFn({ 
      on401: "throw",
      includeToken: true 
    }),
  });
  
  // Fetch pending approvals
  const { data: pendingApprovalsData } = useQuery<UsersResponse>({
    queryKey: ['/api/users/approval/pending'],
    queryFn: getQueryFn({ 
      on401: "throw",
      includeToken: true 
    }),
  });
  
  // Approve user mutation
  const approveUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest('PATCH', `/api/users/${userId}/approve`, {}, true);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "User approved",
        description: "The user has been approved successfully.",
      });
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/employee'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/agent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/approval/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error approving user",
        description: error instanceof Error ? error.message : "There was an error approving the user.",
      });
    }
  });
  
  // Reject user mutation
  const rejectUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest('PATCH', `/api/users/${userId}/reject`, {}, true);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "User rejected",
        description: "The user has been rejected successfully.",
      });
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/employee'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/agent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/approval/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error rejecting user",
        description: error instanceof Error ? error.message : "There was an error rejecting the user.",
      });
    }
  });
  
  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest('DELETE', `/api/users/${userId}`, {}, true);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "User deleted",
        description: "The user has been deleted successfully.",
      });
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/employee'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/agent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error deleting user",
        description: error instanceof Error ? error.message : "There was an error deleting the user.",
      });
    }
  });
  
  // Handle delete user
  const handleDeleteUser = (userId: number, userName: string) => {
    if (confirm(`Are you sure you want to delete ${userName}?`)) {
      deleteUserMutation.mutate(userId);
    }
  };
  
  // Create user form
  const form = useForm<CreateUserFormValues>({
    resolver: zodResolver(createUserSchema),
    defaultValues: {
      fullName: "",
      email: "",
      username: "",
      password: "",
      role: UserRole.EMPLOYEE,
      approvalStatus: "PENDING",
      telegramId: ""
    },
  });

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (data: CreateUserFormValues) => {
      console.log("Submitting user registration:", data);
      try {
        const response = await apiRequest('POST', '/api/users/register', data, true);
        return await response.json();
      } catch (error) {
        console.error("Error creating user:", error);
        throw error; // Re-throw to trigger onError handler
      }
    },
    onSuccess: (data) => {
      console.log("User created successfully:", data);
      toast({
        title: "User created",
        description: "The user has been created successfully.",
      });
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/employee'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/agent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      // Reset form and close dialog
      form.reset();
      setDialogOpen(false);
    },
    onError: (error) => {
      console.error("Error in createUserMutation:", error);
      toast({
        variant: "destructive",
        title: "Error creating user",
        description: error instanceof Error ? error.message : "There was an error creating the user.",
      });
    }
  });

  // Handle form submission
  const onSubmit = (data: CreateUserFormValues) => {
    createUserMutation.mutate(data);
  };
  
  // Format stats data
  const stats = {
    employeeCount: statsData?.employeeCount || 0,
    agentCount: statsData?.agentCount || 0,
    pendingApprovalsCount: statsData?.pendingApprovalsCount || 0,
    activeBreaksCount: statsData?.activeBreaksCount || 0,
    monthlyFinesTotal: statsData?.monthlyFinesTotal || 0
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold text-gray-900">Admin Dashboard</h1>
            <Badge variant="outline" className="ml-4 bg-purple-100 text-purple-800 hover:bg-purple-100">
              Administrator
            </Badge>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-700 text-right">
              <p className="font-medium">{user.fullName}</p>
              <p>{user.email}</p>
            </div>
            <Avatar>
              <AvatarImage src={user.profileImage || undefined} alt={user.fullName} />
              <AvatarFallback>{user.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
            </Avatar>
            <Button variant="ghost" size="icon" onClick={onLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-indigo-500 rounded-md p-3">
                  <Users className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <div>
                    <p className="text-sm font-medium text-gray-500 truncate">Total Employees</p>
                    <div className="flex items-baseline">
                      <p className="text-2xl font-semibold text-gray-900">{stats.employeeCount}</p>
                      <p className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                        <span className="sr-only">Increased by</span>
                        12%
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-red-500 rounded-md p-3">
                  <Timer className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <div>
                    <p className="text-sm font-medium text-gray-500 truncate">Active Breaks</p>
                    <div className="flex items-baseline">
                      <p className="text-2xl font-semibold text-gray-900">{stats.activeBreaksCount}</p>
                      <p className="ml-2 flex items-baseline text-sm font-semibold text-red-600">
                        <span className="sr-only">Active breaks</span>
                        Now
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-yellow-500 rounded-md p-3">
                  <FileCheck className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <div>
                    <p className="text-sm font-medium text-gray-500 truncate">Pending Approvals</p>
                    <div className="flex items-baseline">
                      <p className="text-2xl font-semibold text-gray-900">{stats.pendingApprovalsCount}</p>
                      {stats.pendingApprovalsCount > 0 && (
                        <p className="ml-2 flex items-baseline text-sm font-semibold text-yellow-600">
                          <span className="sr-only">Pending</span>
                          Action Required
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-green-500 rounded-md p-3">
                  <DollarSign className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <div>
                    <p className="text-sm font-medium text-gray-500 truncate">Total Fines (Month)</p>
                    <div className="flex items-baseline">
                      <p className="text-2xl font-semibold text-gray-900">${stats.monthlyFinesTotal.toFixed(2)}</p>
                      <p className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                        <span className="sr-only">Total fines</span>
                        Collected
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Main Tabs */}
        <Tabs 
          defaultValue="employees" 
          onValueChange={setActiveTab}
          value={activeTab}
          className="space-y-8"
        >
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 h-auto">
            <TabsTrigger value="employees">Employees Management</TabsTrigger>
            <TabsTrigger value="agents">Agents Management</TabsTrigger>
            <TabsTrigger value="approvals">Pending Approvals</TabsTrigger>
            <TabsTrigger value="reports">Reports & Analytics</TabsTrigger>
          </TabsList>
          
          {/* Employees Tab */}
          <TabsContent value="employees">
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-medium text-gray-900">Employees</h2>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Input type="text" placeholder="Search employees..." className="pl-10 pr-3" />
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                </div>
                <Button onClick={() => setDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Employee
                </Button>
              </div>
            </div>
            
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>ID</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Breaks Today</TableHead>
                      <TableHead>Fines (MTD)</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employeesData?.users?.map((employee) => (
                      <TableRow key={employee.id}>
                        <TableCell>
                          <div className="flex items-center">
                            <Avatar className="h-10 w-10 mr-4">
                              <AvatarImage src={employee.profileImage || undefined} alt={employee.fullName} />
                              <AvatarFallback>{employee.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{employee.fullName}</div>
                              <div className="text-sm text-gray-500">{employee.email}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{employee.employeeId}</TableCell>
                        <TableCell>{employee.department || 'N/A'}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                            Active
                          </Badge>
                        </TableCell>
                        <TableCell>0 / 5</TableCell>
                        <TableCell>$0.00</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon">
                              <Eye className="h-4 w-4 text-blue-600" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4 text-blue-600" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleDeleteUser(employee.id, employee.fullName)}
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {(!employeesData?.users || employeesData.users.length === 0) && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-6 text-gray-500">
                          No employees found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
                
                {/* Pagination */}
                <div className="flex items-center justify-between px-4 py-3 border-t">
                  <div className="flex-1 flex justify-between sm:hidden">
                    <Button variant="outline" size="sm">Previous</Button>
                    <Button variant="outline" size="sm">Next</Button>
                  </div>
                  <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                    <div>
                      <p className="text-sm text-gray-700">
                        Showing <span className="font-medium">1</span> to{" "}
                        <span className="font-medium">
                          {employeesData?.users?.length || 0}
                        </span>{" "}
                        of <span className="font-medium">{stats.employeeCount}</span> results
                      </p>
                    </div>
                    <div>
                      <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                        <Button variant="outline" size="icon" className="rounded-l-md">
                          <span className="sr-only">Previous</span>
                          &lt;
                        </Button>
                        <Button variant="outline" size="sm" className="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                          1
                        </Button>
                        <Button variant="outline" size="icon" className="rounded-r-md">
                          <span className="sr-only">Next</span>
                          &gt;
                        </Button>
                      </nav>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Agents Tab */}
          <TabsContent value="agents">
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-medium text-gray-900">Agents</h2>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Input type="text" placeholder="Search agents..." className="pl-10 pr-3" />
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                </div>
                <Button 
                  onClick={() => {
                    form.reset({
                      ...form.getValues(),
                      role: UserRole.AGENT,
                      approvalStatus: "APPROVED"
                    });
                    setDialogOpen(true);
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Agent
                </Button>
              </div>
            </div>
            
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Agent</TableHead>
                      <TableHead>ID</TableHead>
                      <TableHead>Region</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Employees</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {agentsData?.users?.map((agent) => (
                      <TableRow key={agent.id}>
                        <TableCell>
                          <div className="flex items-center">
                            <Avatar className="h-10 w-10 mr-4">
                              <AvatarImage src={agent.profileImage || undefined} alt={agent.fullName} />
                              <AvatarFallback>{agent.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{agent.fullName}</div>
                              <div className="text-sm text-gray-500">{agent.email}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{agent.employeeId}</TableCell>
                        <TableCell>{agent.region || 'Global'}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                            Active
                          </Badge>
                        </TableCell>
                        <TableCell>0</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon">
                              <Eye className="h-4 w-4 text-blue-600" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4 text-blue-600" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleDeleteUser(agent.id, agent.fullName)}
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {(!agentsData?.users || agentsData.users.length === 0) && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-6 text-gray-500">
                          No agents found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Approvals Tab */}
          <TabsContent value="approvals">
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-medium text-gray-900">Pending Approvals</h2>
              <div className="inline-flex rounded-md shadow-sm">
                <Button variant="outline" className="rounded-l-md">All</Button>
                <Button variant="outline" className="rounded-none">Employees</Button>
                <Button variant="outline" className="rounded-r-md">Agents</Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              {pendingApprovalsData?.users?.map((user) => (
                <Card key={user.id}>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <div>
                      <CardTitle>{user.role === UserRole.EMPLOYEE ? 'Employee' : 'Agent'} Application</CardTitle>
                      <p className="text-sm text-gray-500">
                        Submitted on {user.joinDate ? format(new Date(user.joinDate), 'PP') : 'recently'}
                      </p>
                    </div>
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                      Pending
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <dl className="divide-y divide-gray-200">
                      <div className="py-3 grid grid-cols-3 gap-4">
                        <dt className="text-sm font-medium text-gray-500">Full name</dt>
                        <dd className="text-sm text-gray-900 col-span-2">{user.fullName}</dd>
                      </div>
                      <div className="py-3 grid grid-cols-3 gap-4">
                        <dt className="text-sm font-medium text-gray-500">Email address</dt>
                        <dd className="text-sm text-gray-900 col-span-2">{user.email}</dd>
                      </div>
                      <div className="py-3 grid grid-cols-3 gap-4">
                        <dt className="text-sm font-medium text-gray-500">
                          {user.role === UserRole.EMPLOYEE ? 'Department' : 'Region'}
                        </dt>
                        <dd className="text-sm text-gray-900 col-span-2">
                          {user.role === UserRole.EMPLOYEE ? (user.department || 'Not specified') : (user.region || 'Global')}
                        </dd>
                      </div>
                      <div className="py-3 grid grid-cols-3 gap-4">
                        <dt className="text-sm font-medium text-gray-500">Position</dt>
                        <dd className="text-sm text-gray-900 col-span-2">{user.position || 'Not specified'}</dd>
                      </div>
                    </dl>
                    
                    <div className="mt-4 flex justify-end space-x-3">
                      <Button 
                        variant="destructive"
                        onClick={() => rejectUserMutation.mutate(user.id)}
                        disabled={rejectUserMutation.isPending}
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Reject
                      </Button>
                      <Button 
                        variant="default"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => approveUserMutation.mutate(user.id)}
                        disabled={approveUserMutation.isPending}
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Approve
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {(!pendingApprovalsData?.users || pendingApprovalsData.users.length === 0) && (
                <div className="lg:col-span-2 text-center py-12 text-gray-500">
                  <p>No pending approvals</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* Reports Tab */}
          <TabsContent value="reports">
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-medium text-gray-900">Reports & Analytics</h2>
              <div className="flex items-center space-x-2">
                <Select defaultValue="7days">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7days">Last 7 Days</SelectItem>
                    <SelectItem value="30days">Last 30 Days</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                    <SelectItem value="quarter">Last Quarter</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <FileDown className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              {/* Break Distribution Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Break Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-gray-100 rounded">
                    <p className="text-gray-500">Chart visualization would go here</p>
                  </div>
                  <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-semibold text-gray-900">0</div>
                      <div className="text-sm text-gray-500">Washroom Breaks</div>
                    </div>
                    <div>
                      <div className="text-2xl font-semibold text-gray-900">0</div>
                      <div className="text-sm text-gray-500">Cigarette Breaks</div>
                    </div>
                    <div>
                      <div className="text-2xl font-semibold text-gray-900">0</div>
                      <div className="text-sm text-gray-500">Meal Breaks</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Fines Overview Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Fines Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-gray-100 rounded">
                    <p className="text-gray-500">Chart visualization would go here</p>
                  </div>
                  <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-semibold text-gray-900">${stats.monthlyFinesTotal.toFixed(2)}</div>
                      <div className="text-sm text-gray-500">Break Violations</div>
                    </div>
                    <div>
                      <div className="text-2xl font-semibold text-gray-900">$0.00</div>
                      <div className="text-sm text-gray-500">Late Returns</div>
                    </div>
                    <div>
                      <div className="text-2xl font-semibold text-gray-900">${stats.monthlyFinesTotal.toFixed(2)}</div>
                      <div className="text-sm text-gray-500">Total Fines</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Top Performers and Violations */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Top Performers */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Performers</CardTitle>
                </CardHeader>
                <CardContent>
                  {employeesData?.users && employeesData.users.length > 0 ? (
                    <ul className="divide-y divide-gray-200">
                      {employeesData.users.slice(0, 3).map((employee) => (
                        <li key={employee.id} className="py-3 flex justify-between items-center">
                          <div className="flex items-center">
                            <Avatar className="h-10 w-10 mr-3">
                              <AvatarImage src={employee.profileImage || undefined} alt={employee.fullName} />
                              <AvatarFallback>{employee.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-sm font-medium text-gray-900">{employee.fullName}</p>
                              <p className="text-sm text-gray-500">{employee.department || 'N/A'}</p>
                            </div>
                          </div>
                          <div className="text-sm text-green-600 font-medium">$0 Fines</div>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-center py-4 text-gray-500">No data available</p>
                  )}
                </CardContent>
              </Card>
              
              {/* Top Violations */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Violations</CardTitle>
                </CardHeader>
                <CardContent>
                  {employeesData?.users && employeesData.users.length > 0 ? (
                    <ul className="divide-y divide-gray-200">
                      {employeesData.users.slice(0, 3).map((employee) => (
                        <li key={employee.id} className="py-3 flex justify-between items-center">
                          <div className="flex items-center">
                            <Avatar className="h-10 w-10 mr-3">
                              <AvatarImage src={employee.profileImage || undefined} alt={employee.fullName} />
                              <AvatarFallback>{employee.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-sm font-medium text-gray-900">{employee.fullName}</p>
                              <p className="text-sm text-gray-500">{employee.department || 'N/A'}</p>
                            </div>
                          </div>
                          <div className="text-sm text-red-600 font-medium">$0 Fines</div>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-center py-4 text-gray-500">No data available</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Create User Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add New User</DialogTitle>
            <DialogDescription>
              Create a new employee or agent account. Fill in all required fields below.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="johndoe@example.com" type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input placeholder="johndoe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value={UserRole.EMPLOYEE}>Employee</SelectItem>
                        <SelectItem value={UserRole.AGENT}>Agent</SelectItem>
                        <SelectItem value={UserRole.ADMIN}>Admin</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <FormControl>
                      <Input placeholder="Engineering" {...field} />
                    </FormControl>
                    <FormDescription>
                      Optional department or team for the user
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="telegramId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Telegram ID</FormLabel>
                    <FormControl>
                      <Input placeholder="123456789" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormDescription>
                      Optional Telegram ID for notifications
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  type="button" 
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createUserMutation.isPending}
                >
                  {createUserMutation.isPending ? "Creating..." : "Create User"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
