import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";

import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User, BreakType, BreakLimits, Break } from "@shared/schema";
import { format, formatDistanceToNow, formatDuration, intervalToDuration } from "date-fns";
import { playSpotifyTrack, pauseSpotifyTrack } from "@/lib/spotify";
import { generateImageWithOpenAI, createVoiceWithOpenAI } from "@/lib/openai";
import { askGemini } from "@/lib/gemini";

import { 
  Clock, 
  LogOut, 
  TimerOff, 
  Timer, 
  Edit, 
  PlayCircle, 
  PauseCircle, 
  SkipBack, 
  SkipForward,
  FileText,
  Image,
  Mic,
  Bot
} from "lucide-react";

interface EmployeeDashboardProps {
  user: User;
  onLogout: () => void;
}

export function EmployeeDashboard({ user, onLogout }: EmployeeDashboardProps) {
  const { toast } = useToast();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState({
    name: "Shape of You",
    artist: "Ed Sheeran",
    duration: "3:55",
    progress: 45,
    currentTime: "1:45"
  });
  
  // Timer for updating current time
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Calculate shift times
  const shiftStart = new Date();
  shiftStart.setHours(12, 30, 0);
  
  const shiftEnd = new Date();
  shiftEnd.setHours(0, 30, 0);
  if (shiftEnd < shiftStart) {
    shiftEnd.setDate(shiftEnd.getDate() + 1);
  }
  
  // Calculate elapsed and remaining time
  const timeElapsed = intervalToDuration({
    start: shiftStart,
    end: currentTime < shiftStart ? shiftStart : currentTime
  });
  
  const timeRemaining = intervalToDuration({
    start: currentTime > shiftEnd ? shiftEnd : currentTime,
    end: shiftEnd
  });
  
  // Format durations
  const formatTimeDisplay = (duration: Duration) => {
    return formatDuration(duration, { format: ['hours', 'minutes', 'seconds'] })
      .replace(/hours?/, 'h')
      .replace(/minutes?/, 'm')
      .replace(/seconds?/, 's');
  };
  
  // Fetch active break
  const { data: activeBreakData, refetch: refetchActiveBreak } = useQuery({
    queryKey: ['/api/breaks/active'],
    refetchInterval: 1000 // Refetch every second to update timer
  });
  
  const activeBreak = activeBreakData?.breaks?.[0];
  
  // Start break mutation
  const startBreakMutation = useMutation({
    mutationFn: async (breakType: string) => {
      const response = await apiRequest('POST', '/api/breaks', { breakType });
      return response.json();
    },
    onSuccess: () => {
      refetchActiveBreak();
      toast({
        title: "Break started",
        description: "Your break has been started successfully.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error starting break",
        description: error instanceof Error ? error.message : "There was an error starting your break.",
      });
    }
  });
  
  // End break mutation
  const endBreakMutation = useMutation({
    mutationFn: async (breakId: number) => {
      const response = await apiRequest('PATCH', `/api/breaks/${breakId}/end`, {});
      return response.json();
    },
    onSuccess: (data) => {
      refetchActiveBreak();
      if (data.fine) {
        toast({
          variant: "destructive",
          title: "Break ended with fine",
          description: `You were late and received a $${data.fine.amount} fine.`,
        });
      } else {
        toast({
          title: "Break ended",
          description: "Your break has been ended successfully.",
        });
      }
      queryClient.invalidateQueries({ queryKey: ['/api/breaks/user', user.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/fines/user', user.id] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error ending break",
        description: error instanceof Error ? error.message : "There was an error ending your break.",
      });
    }
  });
  
  // Calculate break progress and time
  const calculateBreakInfo = (breakRecord: Break) => {
    if (!breakRecord) return { timeLeft: "00:00", progress: 0, isLate: false };
    
    const startTime = new Date(breakRecord.startTime);
    const currentTime = new Date();
    const elapsedSeconds = Math.floor((currentTime.getTime() - startTime.getTime()) / 1000);
    
    const breakLimitSeconds = BreakLimits[breakRecord.breakType as keyof typeof BreakLimits] * 60;
    const remainingSeconds = breakLimitSeconds - elapsedSeconds;
    
    const minutes = Math.floor(Math.max(0, remainingSeconds) / 60);
    const seconds = Math.max(0, remainingSeconds) % 60;
    const timeLeft = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    const progress = Math.min(100, (elapsedSeconds / breakLimitSeconds) * 100);
    const isLate = elapsedSeconds > breakLimitSeconds;
    
    return { timeLeft, progress, isLate };
  };
  
  // Fetch break history
  const { data: breaksData } = useQuery({
    queryKey: ['/api/breaks/user', user.id]
  });
  
  // Fetch fines
  const { data: finesData } = useQuery({
    queryKey: ['/api/fines/user', user.id]
  });
  
  // Handle Spotify controls
  const handlePlayPause = () => {
    if (isPlaying) {
      pauseSpotifyTrack();
    } else {
      playSpotifyTrack();
    }
    setIsPlaying(!isPlaying);
  };
  
  // Handle AI interactions
  const handleAskGemini = async () => {
    try {
      const question = prompt("What would you like to ask Gemini?");
      if (!question) return;
      
      toast({
        title: "Asking Gemini...",
        description: "Please wait while we process your request."
      });
      
      const response = await askGemini(question);
      
      toast({
        title: "Gemini Response",
        description: response.length > 100 ? response.substring(0, 100) + "..." : response,
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to communicate with Gemini AI."
      });
    }
  };
  
  const handleGenerateImage = async () => {
    try {
      const prompt = prompt("Describe the image you want to generate:");
      if (!prompt) return;
      
      toast({
        title: "Generating image...",
        description: "Please wait while we process your request."
      });
      
      const imageUrl = await generateImageWithOpenAI(prompt);
      
      toast({
        title: "Image Generated",
        description: "Your image has been generated successfully."
      });
      
      // Open image in new tab
      window.open(imageUrl, '_blank');
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to generate image with OpenAI."
      });
    }
  };
  
  const handleCreateVoice = async () => {
    try {
      const text = prompt("Enter the text you want to convert to speech:");
      if (!text) return;
      
      toast({
        title: "Creating voice...",
        description: "Please wait while we process your request."
      });
      
      const audioUrl = await createVoiceWithOpenAI(text);
      
      toast({
        title: "Voice Created",
        description: "Your voice clip has been created successfully."
      });
      
      // Open audio in new tab
      window.open(audioUrl, '_blank');
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create voice with OpenAI."
      });
    }
  };
  
  // Get break info if active
  const breakInfo = activeBreak ? calculateBreakInfo(activeBreak) : null;
  
  // Get break type name
  const getBreakTypeName = (breakType: string) => {
    switch (breakType) {
      case BreakType.WASHROOM: return "Washroom Break (WC)";
      case BreakType.CIGARETTE: return "Cigarette Break (CY)";
      case BreakType.MEAL: return "Meal Break (ML)";
      default: return breakType;
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold text-gray-900">Employee Dashboard</h1>
            <Badge variant="outline" className="ml-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
              {user.employeeId}
            </Badge>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-700 text-right">
              <p className="font-medium">{user.fullName}</p>
              <p>{user.email}</p>
            </div>
            <Avatar>
              <AvatarImage src={user.profileImage} alt={user.fullName} />
              <AvatarFallback>{user.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
            </Avatar>
            <Button variant="ghost" size="icon" onClick={onLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Duty Status Card */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">Duty Status</CardTitle>
                <div className="flex items-center">
                  <span className="relative flex h-3 w-3 mr-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                  </span>
                  <span className="text-sm font-medium text-green-700">On Duty</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-500">Shift Start</div>
                    <div className="text-lg font-medium mt-1">
                      {format(shiftStart, 'h:mm a')}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-500">Shift End</div>
                    <div className="text-lg font-medium mt-1">
                      {format(shiftEnd, 'h:mm a')}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-500">Time Elapsed</div>
                    <div className="text-lg font-medium mt-1">
                      {formatTimeDisplay(timeElapsed)}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-500">Time Remaining</div>
                    <div className="text-lg font-medium mt-1">
                      {formatTimeDisplay(timeRemaining)}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Break Management Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Break Management</CardTitle>
              </CardHeader>
              <CardContent>
                {!activeBreak ? (
                  <div className="space-y-4">
                    <p className="text-gray-600">Start a break by selecting one of the options below:</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button 
                        variant="outline" 
                        className="h-auto py-4 px-4 justify-between" 
                        onClick={() => startBreakMutation.mutate(BreakType.WASHROOM)}
                        disabled={startBreakMutation.isPending}
                      >
                        <div className="text-left">
                          <div className="font-medium">Washroom Break (WC)</div>
                          <div className="text-sm text-gray-500">15 minute limit</div>
                        </div>
                        <Clock className="h-5 w-5 text-gray-400" />
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        className="h-auto py-4 px-4 justify-between"
                        onClick={() => startBreakMutation.mutate(BreakType.CIGARETTE)}
                        disabled={startBreakMutation.isPending}
                      >
                        <div className="text-left">
                          <div className="font-medium">Cigarette Break (CY)</div>
                          <div className="text-sm text-gray-500">10 minute limit</div>
                        </div>
                        <Clock className="h-5 w-5 text-gray-400" />
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        className="h-auto py-4 px-4 justify-between"
                        onClick={() => startBreakMutation.mutate(BreakType.MEAL)}
                        disabled={startBreakMutation.isPending}
                      >
                        <div className="text-left">
                          <div className="font-medium">Meal Break (ML)</div>
                          <div className="text-sm text-gray-500">30 minute limit</div>
                        </div>
                        <Clock className="h-5 w-5 text-gray-400" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-blue-800">
                          {getBreakTypeName(activeBreak.breakType)}
                        </h3>
                        <p className="text-sm text-blue-600">
                          Started at {format(new Date(activeBreak.startTime), 'h:mm a')}
                        </p>
                      </div>
                      <div className="text-center">
                        <div className={`text-2xl font-bold ${breakInfo?.isLate ? 'text-red-800' : 'text-blue-800'}`}>
                          {breakInfo?.timeLeft}
                        </div>
                        <p className="text-sm text-blue-600">
                          {BreakLimits[activeBreak.breakType as keyof typeof BreakLimits]} min limit
                        </p>
                      </div>
                    </div>
                    
                    <div className="mt-3">
                      <Progress 
                        value={breakInfo?.progress} 
                        className={`h-2.5 ${breakInfo?.isLate ? 'bg-red-200' : 'bg-blue-200'}`}
                        indicatorClassName={breakInfo?.isLate ? 'bg-red-600' : 'bg-blue-600'}
                      />
                    </div>
                    
                    <div className="mt-4">
                      <Button 
                        className="w-full" 
                        onClick={() => endBreakMutation.mutate(activeBreak.id)}
                        disabled={endBreakMutation.isPending}
                      >
                        <TimerOff className="mr-2 h-4 w-4" />
                        {breakInfo?.isLate ? 'End Break (Late)' : 'Back on time'}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Recent Activity Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                {breaksData?.breaks && breaksData.breaks.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Start Time</TableHead>
                        <TableHead>End Time</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {breaksData.breaks
                        .filter(breakRecord => breakRecord.endTime) // Only show completed breaks
                        .slice(0, 5) // Show only last 5 breaks
                        .map((breakRecord) => {
                          const duration = breakRecord.duration 
                            ? Math.floor(breakRecord.duration / 60) + 'm ' + (breakRecord.duration % 60) + 's' 
                            : 'N/A';
                          
                          return (
                            <TableRow key={breakRecord.id}>
                              <TableCell>{getBreakTypeName(breakRecord.breakType)}</TableCell>
                              <TableCell>{format(new Date(breakRecord.startTime), 'h:mm a')}</TableCell>
                              <TableCell>
                                {breakRecord.endTime 
                                  ? format(new Date(breakRecord.endTime), 'h:mm a') 
                                  : 'Active'}
                              </TableCell>
                              <TableCell>{duration}</TableCell>
                              <TableCell>
                                {breakRecord.isLate ? (
                                  <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">
                                    Late
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                                    On Time
                                  </Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-gray-500 text-center py-4">No recent activity</p>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Right Column */}
          <div className="space-y-6">
            {/* Profile Card */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={user.profileImage} alt={user.fullName} />
                    <AvatarFallback className="text-lg">{user.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="ml-4">
                    <h2 className="text-lg font-medium text-gray-900">{user.fullName}</h2>
                    <p className="text-sm text-gray-500">{user.position}</p>
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <dl className="divide-y divide-gray-200">
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Employee ID</dt>
                    <dd className="text-sm text-gray-900">{user.employeeId}</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Email</dt>
                    <dd className="text-sm text-gray-900">{user.email}</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Department</dt>
                    <dd className="text-sm text-gray-900">{user.department}</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Join Date</dt>
                    <dd className="text-sm text-gray-900">
                      {user.joinDate ? format(new Date(user.joinDate), 'PP') : 'N/A'}
                    </dd>
                  </div>
                </dl>
                
                <div className="mt-4">
                  <Button variant="outline" className="w-full">
                    <Edit className="mr-2 h-4 w-4" />
                    Edit Profile
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Media Integration Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Media Controls</CardTitle>
              </CardHeader>
              <CardContent>
                {/* Spotify Integration */}
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Spotify</h3>
                  <div className="bg-[#1db954] bg-opacity-10 p-3 rounded-lg">
                    <div className="flex items-center">
                      <div className="h-12 w-12 rounded bg-gray-200 flex items-center justify-center">
                        🎵
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="text-sm font-medium">{currentTrack.name}</div>
                        <div className="text-xs text-gray-500">{currentTrack.artist}</div>
                      </div>
                    </div>
                    <div className="mt-3">
                      <Progress value={currentTrack.progress} className="h-1.5 bg-gray-200" indicatorClassName="bg-[#1db954]" />
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>{currentTrack.currentTime}</span>
                        <span>{currentTrack.duration}</span>
                      </div>
                    </div>
                    <div className="mt-3 flex justify-center space-x-6">
                      <Button variant="ghost" size="icon" className="text-gray-700">
                        <SkipBack className="h-5 w-5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-gray-700" onClick={handlePlayPause}>
                        {isPlaying ? <PauseCircle className="h-5 w-5" /> : <PlayCircle className="h-5 w-5" />}
                      </Button>
                      <Button variant="ghost" size="icon" className="text-gray-700">
                        <SkipForward className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* AI Assistant */}
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">AI Assistant</h3>
                  <Button variant="outline" className="w-full" onClick={handleAskGemini}>
                    <Bot className="mr-2 h-4 w-4" />
                    Ask Google Gemini
                  </Button>
                </div>
                
                {/* OpenAI Generator */}
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Content Creator</h3>
                  <div className="flex space-x-2">
                    <Button variant="outline" className="flex-1" onClick={handleGenerateImage}>
                      <Image className="mr-2 h-4 w-4" />
                      Generate Image
                    </Button>
                    <Button variant="outline" className="flex-1" onClick={handleCreateVoice}>
                      <Mic className="mr-2 h-4 w-4" />
                      Create Voice
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Penalty Summary Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Penalty Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="divide-y divide-gray-200">
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">This Month</dt>
                    <dd className="text-sm font-medium text-red-600">
                      ${finesData?.monthly ? finesData.monthly.toFixed(2) : '0.00'}
                    </dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Last Month</dt>
                    <dd className="text-sm text-gray-900">$0.00</dd>
                  </div>
                  <div className="py-3 flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Total Penalties</dt>
                    <dd className="text-sm text-gray-900">
                      ${finesData?.total ? finesData.total.toFixed(2) : '0.00'}
                    </dd>
                  </div>
                </dl>
                
                <div className="mt-4">
                  <Button variant="outline" className="w-full">
                    <FileText className="mr-2 h-4 w-4" />
                    View Penalty Reports
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
