import { useEffect } from 'react';
import { getRedirectResult } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';

/**
 * Component to handle Firebase authentication redirects
 * 
 * This component handles the redirect result when a user signs in with Google via Firebase.
 * It should be placed high up in the component tree, usually in the main App component.
 */
export function FirebaseAuthHandler() {
  const { toast } = useToast();
  const { isLoading } = useAuth();
  
  // Handle redirect result when user is redirected back after Google sign-in
  useEffect(() => {
    async function processRedirect() {
      try {
        // Check if there's a pending redirect authentication
        const result = await getRedirectResult(auth);
        
        if (result) {
          console.log("Successfully authenticated with Firebase via redirect");
          // The actual user will be handled by the AuthProvider's onAuthStateChanged
        }
      } catch (error) {
        console.error("Error handling redirect result:", error);
        
        // Type guard to check if error has a code property
        let errorMessage = "There was a problem signing in with Google. Please try again.";
        
        if (error && typeof error === 'object' && 'code' in error) {
          if (error.code === "auth/configuration-not-found") {
            errorMessage = "Firebase authentication is not properly configured. Please make sure Google authentication is enabled in the Firebase console and this domain is authorized.";
          } else if (error.code === "auth/popup-closed-by-user") {
            errorMessage = "Sign-in was canceled. Please try again when you're ready.";
          } else if (error.code === "auth/popup-blocked") {
            errorMessage = "Sign-in popup was blocked by your browser. Please allow popups for this website.";
          }
        }
        
        toast({
          variant: "destructive",
          title: "Authentication Error",
          description: errorMessage,
        });
      }
    }
    
    // Don't process redirects while main auth is loading
    if (!isLoading) {
      processRedirect();
    }
  }, [isLoading, toast]);
  
  // This component doesn't render anything
  return null;
}