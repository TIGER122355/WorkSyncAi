import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";

import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { User, UserRole } from "@shared/schema";
import { format } from "date-fns";

import { 
  LogOut, 
  Search, 
  Plus,
  Eye, 
  Edit, 
  CheckCircle, 
  XCircle,
  Users,
  Timer,
  FileText
} from "lucide-react";

interface AgentDashboardProps {
  user: User;
  onLogout: () => void;
}

export function AgentDashboard({ user, onLogout }: AgentDashboardProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("employees");
  
  // Fetch employees
  const { data: employeesData } = useQuery({
    queryKey: ['/api/users/role/employee']
  });
  
  // Fetch pending approvals
  const { data: pendingApprovalsData } = useQuery({
    queryKey: ['/api/users/approval/pending']
  });
  
  // Fetch active breaks
  const { data: activeBreaksData } = useQuery({
    queryKey: ['/api/breaks/active'],
    refetchInterval: 10000 // Refetch every 10 seconds
  });
  
  // Approve user mutation
  const approveUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest('PATCH', `/api/users/${userId}/approve`, {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "User approved",
        description: "The user has been approved successfully.",
      });
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/employee'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/approval/pending'] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error approving user",
        description: error instanceof Error ? error.message : "There was an error approving the user.",
      });
    }
  });
  
  // Reject user mutation
  const rejectUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest('PATCH', `/api/users/${userId}/reject`, {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "User rejected",
        description: "The user has been rejected successfully.",
      });
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/role/employee'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/approval/pending'] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error rejecting user",
        description: error instanceof Error ? error.message : "There was an error rejecting the user.",
      });
    }
  });
  
  // Break type name mapping
  const getBreakTypeName = (breakType: string): string => {
    switch (breakType) {
      case 'WC': return 'Washroom Break';
      case 'CY': return 'Cigarette Break';
      case 'ML': return 'Meal Break';
      default: return breakType;
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold text-gray-900">Agent Dashboard</h1>
            <Badge variant="outline" className="ml-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
              Agent
            </Badge>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-700 text-right">
              <p className="font-medium">{user.fullName}</p>
              <p>{user.email}</p>
            </div>
            <Avatar>
              <AvatarImage src={user.profileImage} alt={user.fullName} />
              <AvatarFallback>{user.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
            </Avatar>
            <Button variant="ghost" size="icon" onClick={onLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-blue-500 rounded-md p-3">
                  <Users className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <div>
                    <p className="text-sm font-medium text-gray-500 truncate">Managed Employees</p>
                    <div className="flex items-baseline">
                      <p className="text-2xl font-semibold text-gray-900">
                        {employeesData?.users?.length || 0}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-yellow-500 rounded-md p-3">
                  <Timer className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <div>
                    <p className="text-sm font-medium text-gray-500 truncate">Active Breaks</p>
                    <div className="flex items-baseline">
                      <p className="text-2xl font-semibold text-gray-900">
                        {activeBreaksData?.breaks?.length || 0}
                      </p>
                      {activeBreaksData?.breaks?.length > 0 && (
                        <p className="ml-2 flex items-baseline text-sm font-semibold text-yellow-600">
                          Now
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-green-500 rounded-md p-3">
                  <FileText className="h-5 w-5 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <div>
                    <p className="text-sm font-medium text-gray-500 truncate">Pending Approvals</p>
                    <div className="flex items-baseline">
                      <p className="text-2xl font-semibold text-gray-900">
                        {pendingApprovalsData?.users?.length || 0}
                      </p>
                      {pendingApprovalsData?.users?.length > 0 && (
                        <p className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                          Action Needed
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Main Tabs */}
        <Tabs 
          defaultValue="employees" 
          onValueChange={setActiveTab}
          value={activeTab}
          className="space-y-8"
        >
          <TabsList className="grid w-full grid-cols-2 h-auto">
            <TabsTrigger value="employees">Employee Management</TabsTrigger>
            <TabsTrigger value="approvals">Pending Approvals</TabsTrigger>
          </TabsList>
          
          {/* Employees Tab */}
          <TabsContent value="employees">
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-medium text-gray-900">Employees</h2>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Input type="text" placeholder="Search employees..." className="pl-10 pr-3" />
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                </div>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Employee
                </Button>
              </div>
            </div>
            
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>ID</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Current Break</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employeesData?.users?.map((employee) => {
                      // Find if employee is on active break
                      const activeBreak = activeBreaksData?.breaks?.find(
                        b => b.userId === employee.id
                      );
                      
                      return (
                        <TableRow key={employee.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-4">
                                <AvatarImage src={employee.profileImage} alt={employee.fullName} />
                                <AvatarFallback>{employee.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{employee.fullName}</div>
                                <div className="text-sm text-gray-500">{employee.email}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{employee.employeeId}</TableCell>
                          <TableCell>{employee.department || 'N/A'}</TableCell>
                          <TableCell>
                            {activeBreak ? (
                              <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                                On Break
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                                Active
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            {activeBreak ? (
                              getBreakTypeName(activeBreak.breakType)
                            ) : (
                              'None'
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button variant="ghost" size="icon">
                                <Eye className="h-4 w-4 text-blue-600" />
                              </Button>
                              <Button variant="ghost" size="icon">
                                <Edit className="h-4 w-4 text-blue-600" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    
                    {(!employeesData?.users || employeesData.users.length === 0) && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-6 text-gray-500">
                          No employees found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Approvals Tab */}
          <TabsContent value="approvals">
            <div className="flex justify-between mb-4">
              <h2 className="text-xl font-medium text-gray-900">Pending Approvals</h2>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              {pendingApprovalsData?.users?.filter(u => u.role === UserRole.EMPLOYEE).map((user) => (
                <Card key={user.id}>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <div>
                      <CardTitle>Employee Application</CardTitle>
                      <p className="text-sm text-gray-500">
                        Submitted on {user.joinDate ? format(new Date(user.joinDate), 'PP') : 'recently'}
                      </p>
                    </div>
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                      Pending
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <dl className="divide-y divide-gray-200">
                      <div className="py-3 grid grid-cols-3 gap-4">
                        <dt className="text-sm font-medium text-gray-500">Full name</dt>
                        <dd className="text-sm text-gray-900 col-span-2">{user.fullName}</dd>
                      </div>
                      <div className="py-3 grid grid-cols-3 gap-4">
                        <dt className="text-sm font-medium text-gray-500">Email address</dt>
                        <dd className="text-sm text-gray-900 col-span-2">{user.email}</dd>
                      </div>
                      <div className="py-3 grid grid-cols-3 gap-4">
                        <dt className="text-sm font-medium text-gray-500">Department</dt>
                        <dd className="text-sm text-gray-900 col-span-2">
                          {user.department || 'Not specified'}
                        </dd>
                      </div>
                      <div className="py-3 grid grid-cols-3 gap-4">
                        <dt className="text-sm font-medium text-gray-500">Position</dt>
                        <dd className="text-sm text-gray-900 col-span-2">{user.position || 'Not specified'}</dd>
                      </div>
                    </dl>
                    
                    <div className="mt-4 flex justify-end space-x-3">
                      <Button 
                        variant="destructive"
                        onClick={() => rejectUserMutation.mutate(user.id)}
                        disabled={rejectUserMutation.isPending}
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Reject
                      </Button>
                      <Button 
                        variant="default"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => approveUserMutation.mutate(user.id)}
                        disabled={approveUserMutation.isPending}
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Approve
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {(!pendingApprovalsData?.users || pendingApprovalsData.users.filter(u => u.role === UserRole.EMPLOYEE).length === 0) && (
                <div className="text-center py-12 text-gray-500">
                  <p>No pending employee approvals</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
