import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { UserRole } from "@shared/schema";
import { signInWithGoogle } from "@/lib/firebase";

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";

import { FaGoogle } from "react-icons/fa";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  rememberMe: z.boolean().optional(),
});

type LoginForm = z.infer<typeof loginSchema>;

interface LoginPortalProps {
  onSuccess?: () => void;
}

export function LoginPortal({ onSuccess }: LoginPortalProps) {
  const [, setLocation] = useLocation();
  const [loginType, setLoginType] = useState<string>(UserRole.EMPLOYEE);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { login } = useAuth();

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });

  const handleLogin = async (data: LoginForm) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/auth/login", {
        ...data,
        role: loginType,
      });

      const result = await response.json();
      login(result.user);

      toast({
        title: "Login successful",
        description: `Welcome back, ${result.user.fullName}!`,
      });

      if (onSuccess) {
        onSuccess();
      } else {
        setLocation("/dashboard");
      }
    } catch (error) {
      console.error("Login error:", error);
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "Invalid username or password",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      // Use the signInWithGoogle function from firebase.ts
      await signInWithGoogle();
    } catch (error) {
      console.error("Google Sign-In error:", error);
      
      // Provide more detailed error message
      let errorMessage = "There was an error signing in with Google";
      
      // Type guard to check if error has a code property
      if (error && typeof error === 'object' && 'code' in error && error.code === "auth/configuration-not-found") {
        errorMessage = "Firebase authentication is not properly configured. Please follow these steps in the Firebase console:\n" +
          "1. Enable Google as an authentication provider\n" +
          "2. Add your Replit app URL to the authorized domains\n" +
          "3. Make sure your Firebase project is properly set up";
      }
      
      toast({
        title: "Google Sign-In Failed",
        description: errorMessage,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="flex min-h-screen">
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-r from-blue-600 to-indigo-600 items-center justify-center">
        <div className="max-w-md text-white p-8">
          <h1 className="text-4xl font-bold mb-4">Employee Management System</h1>
          <p className="text-xl opacity-80">
            Complete workforce management with break tracking, profile management, and fine monitoring.
          </p>
          <div className="mt-8 flex space-x-4">
            <div className="flex items-center">
              <span className="mr-2">⏱️</span>
              <span>Break Tracking</span>
            </div>
            <div className="flex items-center">
              <span className="mr-2">👤</span>
              <span>Profile Management</span>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6">
            <div>
              <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
                Sign in to your account
              </h2>
              <div className="mt-4">
                <Tabs
                  defaultValue={UserRole.EMPLOYEE}
                  onValueChange={(value) => setLoginType(value)}
                  className="w-full"
                >
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value={UserRole.EMPLOYEE}>Employee</TabsTrigger>
                    <TabsTrigger value={UserRole.AGENT}>Agent</TabsTrigger>
                    <TabsTrigger value={UserRole.ADMIN}>Admin</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleLogin)} className="mt-8 space-y-6">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your username" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Enter your password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex items-center justify-between">
                  <FormField
                    control={form.control}
                    name="rememberMe"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Remember me
                        </FormLabel>
                      </FormItem>
                    )}
                  />

                  <div className="text-sm">
                    <a href="#" className="font-medium text-blue-600 hover:text-blue-500">
                      Forgot your password?
                    </a>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? "Signing in..." : "Sign in"}
                </Button>

                <div className="mt-6">
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <Separator className="w-full" />
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-2 bg-white text-gray-500">Or continue with</span>
                    </div>
                  </div>

                  <div className="mt-6">
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full"
                      onClick={handleGoogleLogin}
                    >
                      <FaGoogle className="mr-2 h-4 w-4" />
                      Sign in with Google
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
