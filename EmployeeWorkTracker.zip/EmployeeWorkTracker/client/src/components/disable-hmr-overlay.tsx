import { useEffect } from 'react';

/**
 * Component that disables the Vite HMR overlay
 * This is a workaround since we're not allowed to edit vite.config.ts directly
 */
export function DisableHmrOverlay() {
  useEffect(() => {
    // Find and remove any existing HMR overlay elements
    const removeOverlay = () => {
      const overlays = document.querySelectorAll('div.vite-error-overlay');
      overlays.forEach(overlay => {
        overlay.remove();
      });
    };
    
    // Initial cleanup
    removeOverlay();
    
    // Create a mutation observer to remove any newly added overlays
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.addedNodes.length) {
          removeOverlay();
        }
      }
    });
    
    // Start observing the document body for changes
    observer.observe(document.body, { childList: true, subtree: true });
    
    // Clean up the observer when component unmounts
    return () => {
      observer.disconnect();
    };
  }, []);
  
  return null;
}

export default DisableHmrOverlay;