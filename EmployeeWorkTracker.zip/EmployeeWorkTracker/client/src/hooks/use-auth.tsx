import React, { useState, createContext, useContext, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";
import { auth } from "@/lib/firebase";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";

// Auth context type
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (user: User) => void;
  logout: () => void;
}

// Create context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  login: () => {},
  logout: () => {},
});

// Authenticate Firebase user with our backend
const authenticateFirebaseUser = async (firebaseUser: FirebaseUser) => {
  try {
    // Get the ID token from Firebase
    const idToken = await firebaseUser.getIdToken();
    
    if (!idToken) {
      throw new Error("Could not get Firebase ID token");
    }
    
    // Send the token to our backend to verify and authenticate the user
    const response = await apiRequest('POST', '/api/auth/verify-token', {
      idToken
    }, true); // Set includeToken to true to include the Authorization header
    
    const data = await response.json();
    return data.user;
  } catch (error) {
    console.error("Error authenticating Firebase user:", error);
    throw error;
  }
};

// Auth provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  // Firebase authentication mutation
  const firebaseAuthMutation = useMutation({
    mutationFn: authenticateFirebaseUser,
    onSuccess: (userData) => {
      setUser(userData);
      setIsLoading(false);
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      toast({
        title: "Authentication successful",
        description: `Welcome, ${userData.fullName}!`,
      });
    },
    onError: (error) => {
      console.error("Firebase auth error:", error);
      setUser(null);
      setIsLoading(false);
      
      toast({
        variant: "destructive",
        title: "Authentication failed",
        description: error instanceof Error ? error.message : "Failed to authenticate with Firebase.",
      });
    }
  });
  
  // Listen to Firebase auth state changes
  React.useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        // User is signed in with Firebase, authenticate with our backend
        console.log('Firebase user signed in:', firebaseUser.displayName);
        firebaseAuthMutation.mutate(firebaseUser);
      } else {
        // No user is signed in with Firebase
        console.log('No Firebase user signed in');
        setIsLoading(false);
      }
    });
    
    // Listen for custom dev-login-success event for development environments
    const handleDevLogin = (event: CustomEvent<User>) => {
      if (event.detail) {
        login(event.detail);
      }
    };
    
    // Add event listener for custom event
    window.addEventListener('dev-login-success', handleDevLogin as EventListener);
    
    // Cleanup subscriptions on unmount
    return () => {
      unsubscribe();
      window.removeEventListener('dev-login-success', handleDevLogin as EventListener);
    };
  }, []);
  
  // Fetch current user data from our backend
  useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: async () => {
      try {
        const response = await apiRequest('GET', '/api/auth/me', undefined, true); // Include Firebase token
        const data = await response.json();
        if (data && data.user) {
          setUser(data.user);
        }
        return data;
      } catch (error) {
        // If error is 401 Unauthorized, handle gracefully - user isn't logged in
        console.log('Not authenticated with backend yet');
        return null;
      } finally {
        setIsLoading(false);
      }
    },
    enabled: !user, // Only run if no user is set yet
    retry: false,
    refetchOnWindowFocus: false,
  });
  
  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/auth/logout', {}, true); // Include Firebase token
      return response.json();
    },
    onSuccess: () => {
      setUser(null);
      queryClient.clear();
      // Also sign out from Firebase
      auth.signOut();
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: error instanceof Error ? error.message : "There was an error logging out.",
      });
    },
  });
  
  // Handle login
  const login = (userData: User) => {
    setUser(userData);
    toast({
      title: "Login successful",
      description: `Welcome, ${userData.fullName}!`,
    });
  };
  
  // Handle logout
  const logout = () => {
    logoutMutation.mutate();
  };
  
  // Context value
  const value: AuthContextType = {
    user,
    isLoading,
    login,
    logout
  };
  
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to use the auth context
export function useAuth() {
  return useContext(AuthContext);
}