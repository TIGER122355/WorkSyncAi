import { useEffect } from "react";
import { useLocation } from "wouter";
import { LoginPortal } from "@/components/login-portal";
import { LoginButton } from "@/components/login-button";
import { useAuth } from "@/hooks/use-auth";
import { Separator } from "@/components/ui/separator";

export default function Home() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  
  // If user is already logged in, redirect to dashboard
  useEffect(() => {
    if (user) {
      setLocation("/dashboard");
    }
  }, [user, setLocation]);
  
  const handleLoginSuccess = () => {
    setLocation("/dashboard");
  };
  
  return (
    <div className="container mx-auto flex items-center justify-center min-h-screen">
      <div className="w-full max-w-md">
        <div className="space-y-6 bg-white p-8 rounded-xl shadow-lg">
          <div className="text-center">
            <h1 className="text-3xl font-bold">Employee Management System</h1>
            <p className="text-gray-500 mt-2">Login to access your account</p>
          </div>
          
          <LoginButton className="w-full" />
          
          <div className="flex items-center gap-3 my-8">
            <Separator className="flex-1" />
            <span className="text-sm text-gray-500">OR</span>
            <Separator className="flex-1" />
          </div>
          
          <LoginPortal onSuccess={handleLoginSuccess} />
        </div>
      </div>
    </div>
  );
}
