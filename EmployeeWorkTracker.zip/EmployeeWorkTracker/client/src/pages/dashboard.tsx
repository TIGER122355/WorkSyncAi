import { useEffect } from "react";
import { useLocation } from "wouter";
import { EmployeeDashboard } from "@/components/employee-dashboard";
import { AdminDashboard } from "@/components/admin-dashboard";
import { AgentDashboard } from "@/components/agent-dashboard";
import { useAuth } from "@/hooks/use-auth";
import { UserRole } from "@shared/schema";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { user, logout, isLoading } = useAuth();
  
  // If user is not logged in, redirect to home
  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);
  
  // Handle logout
  const handleLogout = () => {
    logout();
    setLocation("/");
  };
  
  // Loading state
  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="ml-2 text-lg text-gray-700">Loading...</span>
      </div>
    );
  }
  
  // Render appropriate dashboard based on user role
  switch (user.role) {
    case UserRole.ADMIN:
      return <AdminDashboard user={user} onLogout={handleLogout} />;
    case UserRole.AGENT:
      return <AgentDashboard user={user} onLogout={handleLogout} />;
    case UserRole.EMPLOYEE:
    default:
      return <EmployeeDashboard user={user} onLogout={handleLogout} />;
  }
}
