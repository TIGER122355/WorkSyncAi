import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { User } from "@shared/schema";

// API response type definitions
export interface StatsResponse {
  employeeCount: number;
  agentCount: number;
  pendingApprovalsCount: number;
  activeBreaksCount: number;
  monthlyFinesTotal: number;
}

export interface UsersResponse {
  users: Array<Omit<User, "password">>;
}

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  includeToken: boolean = false
): Promise<Response> {
  // Set default headers
  const headers: Record<string, string> = {};
  
  // Add content type for requests with data
  if (data) {
    headers["Content-Type"] = "application/json";
  }
  
  // Add authorization header with Firebase ID token if requested
  if (includeToken) {
    try {
      // Import auth at runtime to avoid circular dependencies
      const { auth } = await import("./firebase");
      const currentUser = auth.currentUser;
      
      if (currentUser) {
        const idToken = await currentUser.getIdToken();
        headers["Authorization"] = `Bearer ${idToken}`;
      }
    } catch (error) {
      console.error("Failed to get Firebase token for request:", error);
    }
  }
  
  const res = await fetch(url, {
    method,
    headers,
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
  includeToken?: boolean;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior, includeToken = false }) =>
  async ({ queryKey }) => {
    // Set up headers
    const headers: Record<string, string> = {};
    
    // Add authorization header with Firebase ID token if requested
    if (includeToken) {
      try {
        // Import auth at runtime to avoid circular dependencies
        const { auth } = await import("./firebase");
        const currentUser = auth.currentUser;
        
        if (currentUser) {
          const idToken = await currentUser.getIdToken();
          headers["Authorization"] = `Bearer ${idToken}`;
        }
      } catch (error) {
        console.error("Failed to get Firebase token for query:", error);
      }
    }
    
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
      headers
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ 
        on401: "throw",
        includeToken: true // Enable Firebase token for authenticated requests
      }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
