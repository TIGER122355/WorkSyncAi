/**
 * This module provides functions to interact with Google's Gemini AI model
 */

const GEMINI_API_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent";

/**
 * Ask a question to Google Gemini AI
 */
export async function askGemini(prompt: string): Promise<string> {
  try {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    
    if (!apiKey) {
      throw new Error("Gemini API key is not configured");
    }
    
    const response = await fetch(`${GEMINI_API_ENDPOINT}?key=${apiKey}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 1000,
        },
        safetySettings: [
          {
            category: "HARM_CATEGORY_HATE_SPEECH",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_HARASSMENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          }
        ]
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || "Failed to get response from Gemini");
    }

    const data = await response.json();
    
    // Extract the response text from the data
    const text = data.candidates[0]?.content?.parts[0]?.text;
    
    if (!text) {
      throw new Error("No response text received from Gemini");
    }
    
    return text;
  } catch (error) {
    console.error("Error asking Gemini:", error);
    throw error;
  }
}

/**
 * Generate an answer to a complex question with Gemini
 */
export async function generateAnswer(question: string, context?: string): Promise<string> {
  const prompt = context 
    ? `Based on this context: ${context}\n\nAnswer this question: ${question}`
    : question;
  
  return askGemini(prompt);
}

/**
 * Summarize a text using Gemini
 */
export async function summarizeText(text: string, maxWords?: number): Promise<string> {
  const wordLimit = maxWords ? `in ${maxWords} words or less` : "concisely";
  const prompt = `Summarize the following text ${wordLimit}:\n\n${text}`;
  
  return askGemini(prompt);
}
