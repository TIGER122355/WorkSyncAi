import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithRedirect, signInWithPopup, signInWithEmailAndPassword, AuthError } from "firebase/auth";

// Firebase configuration from environment variables
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

// Check if all required Firebase configuration values are present
if (!firebaseConfig.apiKey || !firebaseConfig.projectId || !firebaseConfig.appId) {
  console.error('Firebase configuration is incomplete. Please check your environment variables.');
}

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication
export const auth = getAuth(app);

// Google auth provider
const googleProvider = new GoogleAuthProvider();

// Configure Google provider
googleProvider.setCustomParameters({
  prompt: 'select_account',  // Always prompt for account selection
});

/**
 * Sign in with Google using Firebase authentication
 * This will try popup first, and if it fails due to unauthorized domain, 
 * it will fallback to the redirect method
 */
export async function signInWithGoogle() {
  try {
    // Try popup first (works better in embedded environments like Replit)
    return await signInWithPopup(auth, googleProvider);
  } catch (error: unknown) {
    console.error("Google Sign-In error:", error);
    // Check if it's a Firebase AuthError and has a code property
    if (error && typeof error === 'object' && 'code' in error) {
      const authError = error as AuthError;
      
      if (authError.code === 'auth/unauthorized-domain') {
        console.warn("This domain is not authorized in Firebase. Using redirect method as fallback.");
        
        // Try redirect method as a fallback
        try {
          // Firebase will redirect back to this page after authentication
          return await signInWithRedirect(auth, googleProvider);
        } catch (redirectError) {
          console.error("Redirect sign-in error:", redirectError);
          throw redirectError;
        }
      }
      
      // For development environments, offer a direct login option
      if (import.meta.env.DEV || import.meta.env.MODE === 'development') {
        console.warn("Running in development mode. Attempting admin login fallback.");
        
        try {
          // Import apiRequest at runtime to avoid circular dependencies
          const { apiRequest } = await import('./queryClient');
          
          const response = await apiRequest('POST', '/api/auth/login', { 
            username: 'admin', 
            password: 'admin123' 
          });
          
          if (response.ok) {
            const data = await response.json();
            console.log("Logged in as admin user for development:", data);
            
            // Don't use window.location.href directly as it bypasses React Router
            // Instead, dispatch a custom event that can be handled by the authentication context
            window.dispatchEvent(new CustomEvent('dev-login-success', { detail: data.user }));
            return;
          }
        } catch (apiError) {
          console.error("API login fallback error:", apiError);
        }
      }
    }
    
    // Rethrow the original error if we couldn't handle it
    throw error;
  }
}

/**
 * Signs out the current user
 */
export function signOut() {
  return auth.signOut();
}

/**
 * Sign in with email and password (fallback method)
 */
export function signInWithEmail(email: string, password: string) {
  return signInWithEmailAndPassword(auth, email, password);
}

export default app;