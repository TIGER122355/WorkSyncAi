# Firebase Deployment Guide

This guide will help you deploy the WorkSync AI application to Firebase Hosting.

## Prerequisites

1. Node.js and npm installed on your local machine
2. Firebase CLI installed globally (`npm install -g firebase-tools`)
3. A Firebase account with the project already created
4. Google authentication enabled in your Firebase project

## Setup Steps

### 1. Clone the repository to your local machine

```bash
git clone <repository-url>
cd worksync-ai
```

### 2. Install dependencies

```bash
npm install
```

### 3. Configure Firebase

Make sure your Firebase project ID in `.firebaserc` matches your actual Firebase project:

```json
{
  "projects": {
    "default": "worksync-ai-49e80"
  }
}
```

### 4. Login to Firebase

```bash
firebase login
```

This will open a browser window for you to authenticate with your Google account.

### 5. Build the application

```bash
npm run build
```

This will create the distribution files in the `dist` directory.

### 6. Deploy to Firebase

```bash
firebase deploy
```

This command will deploy the application to Firebase hosting.

## Environment Variables

Make sure your Firebase project has the following environment variables set up in the Firebase console:

1. `DATABASE_URL` - The URL to your PostgreSQL database
2. `VITE_FIREBASE_API_KEY` - Your Firebase API key
3. `VITE_FIREBASE_APP_ID` - Your Firebase App ID
4. `VITE_FIREBASE_PROJECT_ID` - Your Firebase Project ID
5. `OPENAI_API_KEY` - Optional: Your OpenAI API key if using AI features

## Additional Configuration

### Database Setup

The application uses PostgreSQL for data storage. Make sure your Firebase project has the correct connection string to your database.

### Authentication

The application uses Firebase Authentication with Google Sign-In. Ensure that Google Sign-In is enabled in your Firebase project's Authentication settings.

### Firebase Functions

If you want to use Firebase Functions for server-side processing, make sure the "Blaze" payment plan is enabled on your Firebase project, as functions are not available on the free Spark plan.

## Troubleshooting

### Deployment Issues

If you encounter issues during deployment, try the following:

1. Run `firebase logout` and then `firebase login` to refresh your authentication.
2. Clear the cache with `firebase functions:delete api --force` if you're having function deployment issues.
3. Check the Firebase debug logs with `firebase deploy --debug`.

### Application Issues

If the application is not working correctly after deployment:

1. Check the browser console for any errors.
2. Verify that all environment variables are correctly set.
3. Ensure that the database is accessible from Firebase.
4. Check the Firebase Functions logs in the Firebase console.

## Contact

If you encounter any issues that cannot be resolved using this guide, please contact the development team for assistance.